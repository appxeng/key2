package com.adaptivekb

enum class Kind { CHAR, BACKSPACE, SPACE, ENTER, LAYER }

data class KeyDef(
    val label: String,
    val kind: Kind = Kind.CHAR,
    val out: String = label,
    val weight: Float = 1f,
    val target: Int = 0
) {
    /** فقط کلیدهای تک‌حرفی یاد گرفته می‌شوند */
    val learn: Boolean get() = kind == Kind.CHAR && label.length == 1 && out == label
}

object Palette {
    val accents = intArrayOf(
        0xFF7C6CF0.toInt(), 0xFF1FC8A0.toInt(), 0xFFFF6B81.toInt(),
        0xFF3B9CFF.toInt(), 0xFFFFB02E.toInt(), 0xFFE056C1.toInt()
    )
}

object Layouts {
    private fun row(s: String) = s.split(" ").map { KeyDef(it) }
    private val bs = KeyDef("⌫", Kind.BACKSPACE, weight = 1.5f)

    // لایه ۰: فارسی (چیدمان استاندارد ایران)
    private val fa = listOf(
        row("۱ ۲ ۳ ۴ ۵ ۶ ۷ ۸ ۹ ۰"),
        row("ض ص ث ق ف غ ع ه خ ح ج چ"),
        row("ش س ی ب ل ا ت ن م ک گ"),
        row("ظ ط ژ ز ر ذ د پ و ئ") + bs,
        listOf(
            KeyDef("۱۲۳", Kind.LAYER, weight = 1.4f, target = 2),
            KeyDef("EN", Kind.LAYER, weight = 1.2f, target = 1),
            KeyDef("،"),
            KeyDef("فاصله", Kind.SPACE, weight = 3.6f),
            KeyDef("نیم", Kind.CHAR, out = "\u200c", weight = 1.2f),
            KeyDef("."),
            KeyDef("↵", Kind.ENTER, weight = 1.4f)
        )
    )

    // لایه ۱: انگلیسی
    private val en = listOf(
        row("1 2 3 4 5 6 7 8 9 0"),
        row("q w e r t y u i o p"),
        row("a s d f g h j k l"),
        row("z x c v b n m") + bs,
        listOf(
            KeyDef("۱۲۳", Kind.LAYER, weight = 1.4f, target = 2),
            KeyDef("فا", Kind.LAYER, weight = 1.2f, target = 0),
            KeyDef(","),
            KeyDef("space", Kind.SPACE, weight = 3.6f),
            KeyDef("."),
            KeyDef("↵", Kind.ENTER, weight = 1.4f)
        )
    )

    // لایه ۲: نمادها
    private val sym = listOf(
        row("1 2 3 4 5 6 7 8 9 0"),
        row("! ؟ : ؛ ( ) « » - _ /"),
        row("@ # * + = % & \" ' ~"),
        row("€ ٪ ؛ ، . , ? | < >") + bs,
        listOf(
            KeyDef("ابج", Kind.LAYER, weight = 1.4f, target = 0),
            KeyDef("،"),
            KeyDef("فاصله", Kind.SPACE, weight = 3.6f),
            KeyDef("."),
            KeyDef("↵", Kind.ENTER, weight = 1.4f)
        )
    )

    val layers: List<List<List<KeyDef>>> = listOf(fa, en, sym)
}
