package com.adaptivekb

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.math.sqrt

/** مدل لمس هر کلید: مرکز واقعی لمس (نسبت به مرکز کلید) و پراکندگی */
class KeyStat(
    var mx: Float = 0f, var my: Float = 0f,
    var sx: Float = 0.42f, var sy: Float = 0.42f,
    var hits: Int = 0, var errors: Int = 0
)

class Store private constructor(ctx: Context) {
    private val sp = ctx.applicationContext.getSharedPreferences("akb", Context.MODE_PRIVATE)
    val keys = HashMap<String, KeyStat>()
    val confusion = HashMap<String, Int>()   // "قصد>خورده"
    val words = HashMap<String, Int>()
    val bigrams = HashMap<String, Int>()      // «کلمه‌ی قبلی کلمه‌ی بعدی»
    private var unsaved = 0
    private var frozen: HashMap<String, Float>? = null    // اندازه‌های ثابت‌شده برای هر کلید
    var totalHits = 0                         // تعداد کل ضربه‌های یادگرفته‌شده

    // ---------- تنظیمات ----------
    var accent: Int get() = sp.getInt("accent", 0); set(v) { sp.edit().putInt("accent", v).apply() }
    var theme: Int get() = sp.getInt("theme", 0); set(v) { sp.edit().putInt("theme", v).apply() }
    var keyDp: Int get() = sp.getInt("keyDp", 52); set(v) { sp.edit().putInt("keyDp", v).apply() }
    var adaptive: Boolean get() = sp.getBoolean("adaptive", true); set(v) { sp.edit().putBoolean("adaptive", v).apply() }
    var grow: Boolean get() = sp.getBoolean("grow", true); set(v) { sp.edit().putBoolean("grow", v).apply() }
    var heat: Boolean get() = sp.getBoolean("heat", false); set(v) { sp.edit().putBoolean("heat", v).apply() }
    var haptic: Boolean get() = sp.getBoolean("haptic", true); set(v) { sp.edit().putBoolean("haptic", v).apply() }
    var preview: Boolean get() = sp.getBoolean("preview", true); set(v) { sp.edit().putBoolean("preview", v).apply() }
    var suggest: Boolean get() = sp.getBoolean("suggest", true); set(v) { sp.edit().putBoolean("suggest", v).apply() }

    var numRow: Boolean get() = sp.getBoolean("numRow", false); set(v) { sp.edit().putBoolean("numRow", v).apply() }
    var growPct: Int get() = sp.getInt("growPct", 100); set(v) { sp.edit().putInt("growPct", v).apply() }
    var autoCorrect: Boolean get() = sp.getBoolean("autoCorrect", false); set(v) { sp.edit().putBoolean("autoCorrect", v).apply() }
    var liveAuto: Boolean get() = sp.getBoolean("liveAuto", true); set(v) { sp.edit().putBoolean("liveAuto", v).apply() }
    var liveShow: Boolean get() = sp.getBoolean("liveShow", false); set(v) { sp.edit().putBoolean("liveShow", v).apply() }
    var liveAfter: Int get() = sp.getInt("liveAfter", 800); set(v) { sp.edit().putInt("liveAfter", v).apply() }
    var autoReplace: Boolean get() = sp.getBoolean("autoReplace", true); set(v) { sp.edit().putBoolean("autoReplace", v).apply() }
    var loupe: Boolean get() = sp.getBoolean("loupe", true); set(v) { sp.edit().putBoolean("loupe", v).apply() }
    var sugPos: Int get() = sp.getInt("sugPos", 0); set(v) { sp.edit().putInt("sugPos", v).apply() }   // 0 بالا، 1 نزدیک شست، 2 روی فاصله
    var lang: Int get() = sp.getInt("lang", -1); set(v) { sp.edit().putInt("lang", v).apply() }
    val isFa: Boolean get() = if (lang == -1) Locale.getDefault().language == "fa" else lang == 0

    private val baseSeeds = (
        "است که این را با از برای در به هم یک آن من تو ما شما او آنها بود شد کرد کنم کنی کند کنیم کنید کنند " +
        "دارم داری دارد داریم دارید دارند بله نه خیلی خوب بد سلام خداحافظ ممنون لطفا ببخشید چرا چطور چه کی کجا " +
        "کدام همه هیچ هر اما ولی یا اگر پس چون تا روی زیر بین بعد قبل امروز فردا دیروز الان همیشه هرگز گاهی " +
        "دوست خانه مدرسه کار زندگی وقت روز شب صبح ظهر عصر سال ماه هفته ساعت دقیقه پول ماشین مکانیک راهبه " +
        "تهران ایران نان آب غذا چای قهوه میوه سیب خوشحال ناراحت عالی زیبا بزرگ کوچک جدید قدیمی سریع آرام " +
        "باید شاید حتما واقعا فقط دیگر هنوز همین همان اینجا آنجا کسی چیزی مثل مانند درباره درست غلط سوال " +
        "جواب مشکل کمک تشکر خواهش موفق شاد سلامت تصحیح موشکی کلمه متن ترجمه معنی " +
        "اشتباه املایی تایپی برادر خواهر پدر مادر پسر دختر فرزند خانواده مسلمان عزیز مهربان عشق محبت قلب دل جان چشم دست سر صورت " +
        "دهان گوش بینی بدن سلامتی بیمار دکتر دارو بیمارستان خسته گرسنه تشنه بیدار غمگین عصبانی نگران تنها خدا دنیا آسمان زمین " +
        "خورشید ستاره دریا کوه رود جنگل باغ گل درخت برگ باران برف باد ابر هوا شهر روستا خیابان کوچه میدان پل اتوبوس قطار " +
        "هواپیما مترو تاکسی دوچرخه جاده مسیر سفر مسافر مقصد اتاق آشپزخانه حمام پنجره دیوار سقف مبل میز صندلی تخت فرش چراغ " +
        "تلویزیون تلفن موبایل رایانه کامپیوتر اینترنت برنامه پیام نامه خبر روزنامه مجله فیلم موسیقی آهنگ صدا شعر داستان نویسنده " +
        "شاعر کتابخانه دانشگاه دانشجو معلم استاد درس امتحان نمره کلاس شغل شرکت اداره کارخانه کارگر مدیر بازار فروشگاه مغازه " +
        "قیمت ارزان گران خرید فروش بانک حساب کارت مالیات گفت گفتم گفتی رفت رفتم رفتی آمد آمدم آمدی دید دیدم دیدی شنید شنیدم " +
        "نوشت نوشتم خواند خواندم خورد خوردم داد دادم گرفت گرفتم زد زدم زدند کردم کردی کردند شدم شدی شدند بودم بودی بودند " +
        "هستم هستی هستیم هستید هستند خواهم خواهی خواهد باشد باشم باشی باشند بتوانم بدانم بگویم بروم بیایم بنویسم بخوانم " +
        "بخورم ببینم بدهم بگیرم بزنم خوشگل زشت خوشمزه تازه سخت آسان مهم لازم ممکن آزاد پاک کثیف گرم سرد روشن تاریک بلند " +
        "کوتاه سنگین سبک خالی باز بسته زنده جوان پیر چیز جا مکان زمان لحظه مدت بار مرتبه نفر تعداد همراه کنار پیش پشت جلو " +
        "بالا پایین داخل خارج وسط اول دوم سوم آخر بعدی قبلی اینکه زیرا بنابراین همچنین البته متاسفانه خوشبختانه معمولا " +
        "حدود تقریبا کاملا کمی زیاد بیشتر کمتر بهتر بدتر مثلا یعنی خلاصه ملائک ملائکه میخانه آدم بسرشتند پیمانه دوش دیدم " +
        "خجالت والا بخدا حتی چون هنوز اینهمه"
    ).split(" ")

    init { load(); ensureSeeds(); totalHits = keys.values.sumOf { it.hits }; loadFrozen() }

    fun stat(k: String): KeyStat = keys.getOrPut(k) { KeyStat() }

    fun learnSample(label: String, nx: Float, ny: Float, alpha: Float) {
        val s = stat(label)
        s.mx += alpha * (nx - s.mx)
        s.my += alpha * (ny - s.my)
        val dx = nx - s.mx
        val dy = ny - s.my
        s.sx = sqrt((1 - alpha) * s.sx * s.sx + alpha * dx * dx).coerceIn(0.30f, 0.70f)
        s.sy = sqrt((1 - alpha) * s.sy * s.sy + alpha * dy * dy).coerceIn(0.30f, 0.70f)
        s.mx = s.mx.coerceIn(-0.45f, 0.45f)
        s.my = s.my.coerceIn(-0.45f, 0.45f)
        touched()
    }

    fun strokeCommitted(label: String) {
        stat(label).hits++
        totalHits++
        checkFreeze()
        addDay(1, 0)
    }

    fun recordError(intended: String, hit: String) {
        stat(intended).errors++
        val k = "$intended>$hit"
        confusion[k] = (confusion[k] ?: 0) + 1
        addDay(0, 1)
    }

    fun errorRate(label: String): Float {
        val s = keys[label] ?: return 0f
        val n = s.hits + s.errors
        return if (n < 6) 0f else s.errors.toFloat() / n
    }

    // ---------- اندازه‌ی کلیدها: اول تغییر می‌کند، بعد ثابت می‌ماند ----------
    fun phase2(): Boolean = liveAuto && totalHits >= liveAfter

    private fun rawScale(label: String): Float =
        1f + 0.30f * (growPct / 100f) * minOf(1f, errorRate(label) * 5f)

    private fun freezeNow() {
        val m = HashMap<String, Float>()
        for (k in keys.keys) m[k] = rawScale(k)
        frozen = m
        try { sp.edit().putString("frozen", JSONObject(m as Map<*, *>).toString()).apply() } catch (_: Exception) {}
    }

    fun checkFreeze() { if (phase2() && frozen == null) freezeNow() }

    private fun loadFrozen() {
        val raw = sp.getString("frozen", null) ?: return
        try {
            val o = JSONObject(raw)
            val m = HashMap<String, Float>()
            o.keys().forEach { m[it] = o.getDouble(it).toFloat() }
            frozen = m
        } catch (_: Exception) {}
    }

    /** ضریب پهنای کلید: در مرحله‌ی اول طبق اشتباه‌ها، بعد از آن همان مقدار ثابت‌شده */
    fun sizeScale(label: String): Float {
        if (!grow) return 1f
        if (phase2()) {
            if (frozen == null) freezeNow()
            return frozen!![label] ?: 1f
        }
        if (frozen != null) { frozen = null; sp.edit().remove("frozen").apply() }
        return rawScale(label)
    }

    /**
     * انحراف مشترک لمس روی همه‌ی کلیدها، فقط وقتی که اشتباه‌ها واقعاً هم‌جهت باشند
     * (مثلاً همه به راست). اگر اشتباه‌ها هم به چپ هم به راست باشند، صفر برمی‌گردد.
     */
    fun globalBias(): Pair<Float, Float> {
        val xs = ArrayList<Float>()
        val ys = ArrayList<Float>()
        for (s in keys.values) if (s.errors >= 1) { xs.add(s.mx); ys.add(s.my) }
        if (xs.size < 4) return 0f to 0f
        fun agreed(v: List<Float>): Float {
            val pos = v.count { it > 0.02f }
            val neg = v.count { it < -0.02f }
            return if (pos >= v.size * 0.75f || neg >= v.size * 0.75f) (0.7f * v.average().toFloat()).coerceIn(-0.3f, 0.3f) else 0f
        }
        return agreed(xs) to agreed(ys)
    }

    // ---------- بافت جمله ----------
    fun learnBigram(a: String?, b: String) {
        if (a == null || a.length < 2 || b.length < 2) return
        val k = "$a $b"
        bigrams[k] = (bigrams[k] ?: 0) + 1
        if (bigrams.size > 8000) bigrams.entries.removeAll { it.value <= 1 }
        touched()
    }

    fun bi(a: String?, b: String): Int = if (a == null) 0 else (bigrams["$a $b"] ?: 0)

    /** وقتی کاربر یک تصحیح را برمی‌گرداند، آن کلمه را مطمئن‌تر می‌کنیم */
    fun boost(w: String) { words[w] = (words[w] ?: 0) + 3; touched() }

    private fun ensureSeeds() {
        for (w in baseSeeds + WordBrain.seedWords()) words.putIfAbsent(w, 3)
    }

    // ---------- کلمات ----------
    fun learnWord(w: String) {
        if (w.length < 2) return
        words[w] = (words[w] ?: 0) + 1
        if (words.size > 6000) words.entries.removeAll { it.value <= 1 }
        touched()
    }

    fun prefixWeight(p: String): Int {
        var t = 0
        for ((w, c) in words) if (w.startsWith(p)) t += c
        return t
    }

    fun suggestions(p: String, n: Int = 3): List<String> =
        words.entries.filter { it.key.startsWith(p) && it.key != p }
            .sortedByDescending { it.value }.take(n).map { it.key }

    // ---------- آمار روزانه ----------
    private val fmt = SimpleDateFormat("yyyyMMdd", Locale.US)
    private fun addDay(s: Int, c: Int) {
        val key = "d_" + fmt.format(Date())
        val parts = (sp.getString(key, "0,0") ?: "0,0").split(",")
        val ns = (parts.getOrNull(0)?.toIntOrNull() ?: 0) + s
        val nc = (parts.getOrNull(1)?.toIntOrNull() ?: 0) + c
        sp.edit().putString(key, "$ns,$nc").apply()
        touched()
    }

    /** ۷ روز اخیر: (تعداد ضربه، تعداد اصلاح، شماره روز ماه) */
    fun last7(): List<Triple<Int, Int, Int>> {
        val out = ArrayList<Triple<Int, Int, Int>>()
        for (i in 6 downTo 0) {
            val cal = Calendar.getInstance()
            cal.add(Calendar.DAY_OF_YEAR, -i)
            val parts = (sp.getString("d_" + fmt.format(cal.time), "0,0") ?: "0,0").split(",")
            out.add(Triple(parts[0].toIntOrNull() ?: 0, parts.getOrNull(1)?.toIntOrNull() ?: 0, cal.get(Calendar.DAY_OF_MONTH)))
        }
        return out
    }

    // ---------- ذخیره/بارگذاری ----------
    private fun touched() { if (++unsaved >= 25) save() }

    fun save() {
        unsaved = 0
        try {
            val o = JSONObject()
            val ks = JSONObject()
            for ((k, s) in keys) {
                ks.put(k, JSONArray().put(s.mx.toDouble()).put(s.my.toDouble()).put(s.sx.toDouble())
                    .put(s.sy.toDouble()).put(s.hits).put(s.errors))
            }
            o.put("keys", ks)
            o.put("conf", JSONObject(confusion as Map<*, *>))
            o.put("words", JSONObject(words as Map<*, *>))
            o.put("bi", JSONObject(bigrams as Map<*, *>))
            sp.edit().putString("data", o.toString()).apply()
        } catch (_: Exception) {}
    }

    private fun load() {
        val raw = sp.getString("data", null) ?: return
        try {
            val o = JSONObject(raw)
            o.optJSONObject("keys")?.let { ks ->
                ks.keys().forEach { k ->
                    val a = ks.getJSONArray(k)
                    keys[k] = KeyStat(a.getDouble(0).toFloat(), a.getDouble(1).toFloat(),
                        a.getDouble(2).toFloat(), a.getDouble(3).toFloat(), a.getInt(4), a.getInt(5))
                }
            }
            o.optJSONObject("conf")?.let { c -> c.keys().forEach { confusion[it] = c.getInt(it) } }
            o.optJSONObject("words")?.let { w -> w.keys().forEach { words[it] = w.getInt(it) } }
            o.optJSONObject("bi")?.let { b -> b.keys().forEach { bigrams[it] = b.getInt(it) } }
        } catch (_: Exception) {}
    }

    fun resetLearning() {
        keys.clear(); confusion.clear(); words.clear(); bigrams.clear(); totalHits = 0; frozen = null
        val e = sp.edit()
        for (k in sp.all.keys) if (k.startsWith("d_")) e.remove(k)
        e.remove("data").remove("frozen").apply()
        ensureSeeds()
    }

    companion object {
        /** آیا a و b حداکثر یک ویرایش (جایگزینی، حذف، اضافه، جابجایی دو حرف) فاصله دارند؟ */
        fun within1(a: String, b: String): Boolean {
            if (a == b) return false
            val la = a.length
            val lb = b.length
            if (la == lb) {
                var i = 0
                while (i < la && a[i] == b[i]) i++
                if (i == la) return false
                if (a.substring(i + 1) == b.substring(i + 1)) return true
                return i + 1 < la && a[i] == b[i + 1] && a[i + 1] == b[i] && a.substring(i + 2) == b.substring(i + 2)
            }
            val s = if (la < lb) a else b
            val l = if (la < lb) b else a
            if (l.length - s.length != 1) return false
            var i = 0
            while (i < s.length && s[i] == l[i]) i++
            return s.substring(i) == l.substring(i + 1)
        }

        @Volatile private var inst: Store? = null
        fun get(ctx: Context): Store = inst ?: synchronized(this) {
            inst ?: Store(ctx).also { inst = it }
        }
    }
}
