package com.adaptivekb

import kotlin.math.ln

/** تصحیح هوشمند: کلمه را با توجه به کلمه‌های اطراف جمله می‌سنجد */
object WordBrain {
    private fun set(s: String) = s.split(" ").toSet()
    private fun norm(s: String) = s.replace("\u200c", "")

    /** کلمه -> نشانه‌هایی که معمولاً در جمله کنارش می‌آیند */
    private val cues: Map<String, Set<String>> = mapOf(
        "جمله" to set("تصحیح بنویس بنویسید کامل ترجمه معنی اول آخر مفید کلمه کلمات متن بخوان بخوانید مثال ساده ناقص درست غلط املا دستور انشا"),
        "حمله" to set("موشکی هوایی نظامی تروریستی قلبی ارتش سربازان دشمن جنگ پهپادی زمینی ناگهانی سرباز مهاجم کشته مجروح آتش"),
        "کتاب" to set("خواندم خواندی بخوان کتابخانه مطالعه نویسنده صفحه جلد فصل کتابفروشی چاپ"),
        "کباب" to set("غذا ناهار شام رستوران گوشت برنج سیخ زغال خوردیم نان"),
        "برف" to set("زمستان سرد بارید می‌بارد سفید کوه یخ"),
        "برق" to set("قطع لامپ کابل سیم مصرف قبض پریز شبکه"),
        "شیر" to set("گاو آب جنگل نوشیدم نوشیدن قهوه گرم بطری نوزاد"),
        "سیر" to set("پیاز غذا خوردن شدم شدی سبزی"),
        "رنگ" to set("قرمز آبی زرد سبز نقاشی روشن تیره رنگی دیوار"),
        "زنگ" to set("تلفن در مدرسه تماس موبایل ساعت بزن زدم"),
        "قرار" to set("ملاقات جلسه گذاشتیم گذاشتم دیدار فردا ساعت"),
        "فرار" to set("زندان دزد پلیس مجرم متهم ترس")
    )
    private val cueN: Map<String, Set<String>> = cues.mapValues { e -> e.value.map { norm(it) }.toSet() }

    fun seedWords(): List<String> = cues.keys.toList()

    class Decision(val single: String?, val options: List<String>)
    private val none = Decision(null, emptyList())

    /** جایگزینی یک حرف فقط وقتی «غلط تایپی» حساب می‌شود که دو حرف روی صفحه‌کلید همسایه باشند */
    private fun plausible(a: String, b: String): Boolean {
        if (a.length != b.length) return true
        var i = 0
        while (i < a.length && a[i] == b[i]) i++
        if (i >= a.length) return false
        if (a.substring(i + 1) == b.substring(i + 1))
            return (a[i] == 'ا' && b[i] == 'آ') || b[i].toString() in Layouts.neighbors(a[i].toString())
        return true      // جابجایی دو حرف
    }

    private fun hits(c: String, window: List<String>): Int {
        val s = cueN[c] ?: return 0
        return minOf(2, window.count { norm(it) in s })
    }

    private fun score(store: Store, c: String, prev: String?, next: String?, window: List<String>, stay: Boolean): Float {
        var v = 0.35f * ln(1f + (store.words[c] ?: 0))
        v += 2.5f * hits(c, window)
        v += 1.2f * ln(1f + store.bi(prev, c))
        if (next != null) v += 1.2f * ln(1f + store.bi(c, next))
        if (stay) v += 0.8f
        return v
    }

    /**
     * اگر بافت جمله قاطع باشد، فقط یک کلمه (single) برمی‌گردد؛
     * اگر مبهم باشد، چند گزینه (options) تا کاربر خودش انتخاب کند.
     */
    fun decide(store: Store, w: String, prev: String?, next: String?, window: List<String>): Decision {
        if (w.length < 3 || store.isTrusted(w)) return none
        val known = (store.words[w] ?: 0) > 0
        if (!known && w.length < 4) return none           // کلمه‌ی کوتاهِ ناشناخته را علامت نمی‌زنیم
        val cands = ArrayList<String>()
        for ((c, n) in store.words) {
            if (c == w || c.length < 3) continue
            if (n < 3 && !cues.containsKey(c)) continue
            if (w.startsWith(c) || c.startsWith(w)) continue      // پسوندها (مثل «ی» و «ها») غلط نیستند
            if (Store.within1(w, c) && plausible(w, c)) cands.add(c)
        }
        if (cands.isEmpty()) return none
        val orig = score(store, w, prev, next, window, known)
        val scored = cands.map { it to score(store, it, prev, next, window, false) }
            .sortedByDescending { it.second }
        val top = scored[0]
        val second = scored.getOrNull(1)
        val diff = top.second - orig

        if (!known) {
            if (diff < 0.4f) return none
            if (second != null && top.second - second.second < 0.5f)
                return Decision(null, scored.take(3).map { it.first })
            return Decision(top.first, emptyList())
        }
        if (diff >= 1.5f && (second == null || top.second - second.second >= 0.8f))
            return Decision(top.first, emptyList())
        if (diff >= 0.8f) {
            val opts = arrayListOf(top.first, w)
            if (second != null && second.second > orig) opts.add(second.first)
            return Decision(null, opts)
        }
        return none
    }
}
