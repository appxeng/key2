package com.adaptivekb

enum class Kind { CHAR, BACKSPACE, SPACE, ENTER, LAYER, SHIFT }

data class KeyDef(
    val label: String,
    val kind: Kind = Kind.CHAR,
    val out: String = label,
    val weight: Float = 1f,
    val target: Int = 0,
    val emoji: Boolean = false,
    val alt: Boolean = false
) {
    /** فقط کلیدهای تک‌حرفی یاد گرفته می‌شوند (نه ایموجی و نه حرف‌های فشار طولانی) */
    val learn: Boolean get() = kind == Kind.CHAR && label.length == 1 && out == label && !emoji && !alt
}

object Palette {
    val accents = intArrayOf(
        0xFF7C6CF0.toInt(), 0xFF1FC8A0.toInt(), 0xFFFF6B81.toInt(),
        0xFF3B9CFF.toInt(), 0xFFFFB02E.toInt(), 0xFFE056C1.toInt()
    )
}

object Layouts {
    private fun row(s: String) = s.split(" ").map { KeyDef(it) }
    private val bs = KeyDef("⌫", Kind.BACKSPACE, weight = 1.5f)

    private val marks = listOf(
        "\u064E", "\u064F", "\u0650", "\u064B", "\u064C", "\u064D", "\u0651", "\u0652", "\u0670", "\u0653"
    )

    /** حرف‌های فشار طولانی (مثل کیبورد گوگل) */
    private val baseAlts: Map<String, List<String>> = mapOf(
        "ا" to listOf("آ", "ء", "أ", "إ"),
        "ی" to listOf("ئ", "ي"),
        "و" to listOf("ؤ"),
        "ز" to listOf("ژ"),
        "ه" to listOf("ة", "ۀ"),
        "ک" to listOf("ك"),
        "ج" to listOf("چ"),
        "،" to listOf("؛", "؟", "!", ":"),
        "." to listOf("…", "!", "؟", ":"),
        "/" to listOf("\\"),
        "نیم" to marks,
        "a" to listOf("à", "á", "â", "ä", "ã"),
        "e" to listOf("è", "é", "ê", "ë"),
        "i" to listOf("ì", "í", "î", "ï"),
        "o" to listOf("ò", "ó", "ô", "ö"),
        "u" to listOf("ù", "ú", "û", "ü"),
        "n" to listOf("ñ"), "c" to listOf("ç"), "s" to listOf("ß"),
        "*" to listOf("/", "×", "÷")
    )

    private val digitAlts: Map<String, List<String>> = run {
        val m = HashMap<String, List<String>>()
        for (i in 0..9) {
            val lat = ('0' + i).toString()
            val per = ('\u06F0' + i).toString()
            m[lat] = listOf(per)
            m[per] = listOf(lat)
        }
        m
    }

    val alts: Map<String, List<String>> = baseAlts + digitAlts

    // لایه ۰: فارسی (مثل کیبورد گوگل؛ چ پایین، ژ و ئ با فشار طولانی)
    private val fa = listOf(
        row("۱ ۲ ۳ ۴ ۵ ۶ ۷ ۸ ۹ ۰"),
        row("ض ص ث ق ف غ ع ه خ ح ج"),
        row("ش س ی ب ل ا ت ن م ک گ"),
        row("ظ ط ز ر ذ د پ و چ") + bs,
        listOf(
            KeyDef("۱۲۳", Kind.LAYER, weight = 1.3f, target = 2),
            KeyDef("😊", Kind.LAYER, weight = 1.1f, target = 3, emoji = true),
            KeyDef("🌐", Kind.LAYER, weight = 1.1f, target = 1, emoji = true),
            KeyDef("فارسی", Kind.SPACE, weight = 5.0f),
            KeyDef("نیم", Kind.CHAR, out = "\u200c", weight = 1.1f),
            KeyDef("."),
            KeyDef("↵", Kind.ENTER, weight = 1.3f)
        )
    )

    // لایه ۱: انگلیسی
    private val en = listOf(
        row("1 2 3 4 5 6 7 8 9 0"),
        row("q w e r t y u i o p"),
        row("a s d f g h j k l"),
        listOf(KeyDef("⇧", Kind.SHIFT, weight = 1.5f)) + row("z x c v b n m") + bs,
        listOf(
            KeyDef("123", Kind.LAYER, weight = 1.3f, target = 2),
            KeyDef("😊", Kind.LAYER, weight = 1.1f, target = 3, emoji = true),
            KeyDef("🌐", Kind.LAYER, weight = 1.1f, target = 0, emoji = true),
            KeyDef("English", Kind.SPACE, weight = 5.4f),
            KeyDef("."),
            KeyDef("↵", Kind.ENTER, weight = 1.3f)
        )
    )

    // لایه ۲: اعداد و نمادها
    private val sym = listOf(
        row("1 2 3 4 5 6 7 8 9 0"),
        row("! : ؛ ، ( ) « » - _ /"),
        row("@ # * + = % & \" ' ~ \\"),
        row("€ ٪ . , < > | ؟ ?") + bs,
        listOf(
            KeyDef("ابج", Kind.LAYER, weight = 1.4f, target = 0),
            KeyDef("😊", Kind.LAYER, weight = 1.1f, target = 3, emoji = true),
            KeyDef("\u0640\u064E\u0640\u064F\u0640\u0650", Kind.LAYER, weight = 1.5f, target = 7, emoji = true),
            KeyDef("🔢", Kind.LAYER, weight = 1.1f, target = 8, emoji = true),
            KeyDef("فاصله", Kind.SPACE, weight = 3.6f),
            KeyDef("."),
            KeyDef("↵", Kind.ENTER, weight = 1.4f)
        )
    )

    // لایه‌های ۳ تا ۶: ایموجی
    private val emojiBottom = listOf(
        KeyDef("ابج", Kind.LAYER, weight = 1.6f, target = 0),
        KeyDef("😀", Kind.LAYER, target = 3, emoji = true),
        KeyDef("👍", Kind.LAYER, target = 4, emoji = true),
        KeyDef("❤\uFE0F", Kind.LAYER, target = 5, emoji = true),
        KeyDef("🐱", Kind.LAYER, target = 6, emoji = true),
        KeyDef("⌫", Kind.BACKSPACE, weight = 1.6f)
    )

    private fun emojiPage(s: String): List<List<KeyDef>> =
        s.split(" ").chunked(9).map { r -> r.map { KeyDef(it, emoji = true) } } + listOf(emojiBottom)

    private val e1 = emojiPage("😀 😃 😄 😁 😆 😅 😂 🤣 😊 😇 🙂 😉 😍 🥰 😘 😋 😎 🤩 🥳 😏 😒 😔 😢 😭 😡 🤔 😴")
    private val e2 = emojiPage("👍 👎 👌 ✌\uFE0F 🤞 🤝 👏 🙏 💪 👋 🤚 ✋ 👊 ✊ 🙌 🤲 🖐\uFE0F ☝\uFE0F 👆 👇 👈 👉 🤟 🤘 🤙 💅 🙋")
    private val e3 = emojiPage("❤\uFE0F 🧡 💛 💚 💙 💜 🖤 🤍 💔 ❣\uFE0F 💕 💞 💓 💗 💖 💘 💝 🔥 ✨ ⭐ 🌟 💯 ✅ ❌ ❓ ❗ 🎉")
    private val e4 = emojiPage("🐱 🐶 🐭 🐹 🐰 🦊 🐻 🐼 🐨 🦁 🐯 🐸 🐵 🐔 🐧 🦋 🌹 🌸 🌞 🍎 🍕 🍔 ☕ 🍰 🎂 ⚽ 🚗")

    // لایه ۷: حرکات و حروف صدادار
    private val harakat = listOf(
        marks.map { KeyDef("ـ" + it, out = it, emoji = true) },
        "آ ا و ی ء ئ ؤ أ إ ة ۀ".split(" ").map { KeyDef(it, alt = true) },
        listOf(
            KeyDef("نیم", Kind.CHAR, out = "\u200c", weight = 1.5f),
            KeyDef("ـ", alt = true), KeyDef("،", alt = true),
            KeyDef("؛", alt = true), KeyDef("؟", alt = true), bs
        ),
        listOf(
            KeyDef("ابج", Kind.LAYER, weight = 1.5f, target = 0),
            KeyDef("۱۲۳", Kind.LAYER, weight = 1.3f, target = 2),
            KeyDef("😊", Kind.LAYER, weight = 1.1f, target = 3, emoji = true),
            KeyDef("فاصله", Kind.SPACE, weight = 3.6f),
            KeyDef("↵", Kind.ENTER, weight = 1.4f)
        )
    )

    /** فراوانی تقریبی حرف‌ها (درصد). وقتی لمس بین دو کلید مردد است، حرف پرکاربردتر شانس بیشتری دارد */
    private val freq: Map<String, Float> = mapOf(
        "ا" to 11.5f, "ی" to 7.5f, "ر" to 5.8f, "ن" to 5.6f, "و" to 5.4f, "د" to 4.8f, "م" to 4.8f, "ه" to 4.6f,
        "ت" to 4.4f, "ب" to 3.4f, "ل" to 3.3f, "س" to 3.0f, "ک" to 2.9f, "ش" to 2.0f, "ف" to 1.4f, "ع" to 1.4f,
        "ز" to 1.3f, "خ" to 1.2f, "ق" to 1.2f, "گ" to 1.0f, "ج" to 1.0f, "ح" to 1.0f, "پ" to 0.9f, "چ" to 0.6f,
        "ص" to 0.6f, "ط" to 0.5f, "غ" to 0.4f, "ذ" to 0.3f, "ئ" to 0.3f, "ض" to 0.25f, "ث" to 0.15f, "ظ" to 0.1f, "ژ" to 0.1f,
        "e" to 12.7f, "t" to 9.1f, "a" to 8.2f, "o" to 7.5f, "i" to 7.0f, "n" to 6.7f, "s" to 6.3f, "h" to 6.1f,
        "r" to 6.0f, "d" to 4.3f, "l" to 4.0f, "c" to 2.8f, "u" to 2.8f, "m" to 2.4f, "w" to 2.4f, "f" to 2.2f,
        "g" to 2.0f, "y" to 2.0f, "p" to 1.9f, "b" to 1.5f, "v" to 1.0f, "k" to 0.8f, "j" to 0.15f, "x" to 0.15f,
        "q" to 0.1f, "z" to 0.07f
    )

    fun freqOf(label: String): Float = freq[label] ?: 3f

    /** همه‌ی حرف‌های صفحه‌کلید فارسی (برای پیشنهاد ذره‌بین) */
    fun letters(): List<String> =
        fa.drop(1).take(3).flatten().filter { it.learn }.map { it.label }

    /** حرف‌های همسایه‌ی یک حرف روی صفحه‌کلید (برای ذره‌بین) */
    fun neighbors(label: String): List<String> {
        for (layer in listOf(fa, en)) {
            val rows = layer.drop(1).take(3)
            for ((ri, row) in rows.withIndex()) {
                val ci = row.indexOfFirst { it.learn && it.label == label }
                if (ci < 0) continue
                val out = ArrayList<String>()
                fun add(r: Int, c: Int) {
                    val k = rows.getOrNull(r)?.getOrNull(c) ?: return
                    if (k.learn && k.label != label && k.label !in out) out.add(k.label)
                }
                add(ri, ci - 1); add(ri, ci + 1); add(ri - 1, ci); add(ri + 1, ci)
                add(ri - 1, ci - 1); add(ri - 1, ci + 1); add(ri + 1, ci - 1); add(ri + 1, ci + 1)
                add(ri, ci - 2); add(ri, ci + 2)
                return out
            }
        }
        return emptyList()
    }

    // لایه ۸: صفحه‌ی فقط اعداد (مثل صفحه‌ی تلفن)
    private val numpad = listOf(
        listOf(KeyDef("+"), KeyDef("1", weight = 1.6f), KeyDef("2", weight = 1.6f), KeyDef("3", weight = 1.6f), KeyDef("%")),
        listOf(KeyDef("-"), KeyDef("4", weight = 1.6f), KeyDef("5", weight = 1.6f), KeyDef("6", weight = 1.6f), KeyDef("␣", Kind.SPACE)),
        listOf(KeyDef("*"), KeyDef("7", weight = 1.6f), KeyDef("8", weight = 1.6f), KeyDef("9", weight = 1.6f), KeyDef("⌫", Kind.BACKSPACE)),
        listOf(
            KeyDef("ابج", Kind.LAYER, target = 0),
            KeyDef(","),
            KeyDef("!?#", Kind.LAYER, target = 2),
            KeyDef("0", weight = 1.6f),
            KeyDef("="),
            KeyDef("."),
            KeyDef("↵", Kind.ENTER, weight = 1.2f)
        )
    )

    val layers: List<List<List<KeyDef>>> = listOf(fa, en, sym, e1, e2, e3, e4, harakat, numpad)
}
