package com.adaptivekb

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.os.Handler
import android.os.Looper
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.hypot
import kotlin.math.ln
import kotlin.math.min

class KeyboardView(ctx: Context, private val store: Store) : View(ctx) {

    class RKey(val def: KeyDef, val r: RectF) {
        val cx get() = r.centerX()
        val cy get() = r.centerY()
        val w get() = r.width()
        val h get() = r.height()
    }

    var onKey: ((KeyDef, Float, Float, Float, Float) -> Unit)? = null
    var onSuggestion: ((String) -> Unit)? = null
    var onPicker: (() -> Unit)? = null
    /** فقط برای پیش‌نمایش در تنظیمات: چند کلید را با شکل نمونه نشان می‌دهد */
    var demo = false
    var onSettings: (() -> Unit)? = null
    var currentWord = ""
    var suggestions: List<String> = emptyList()
    var layer = 0
        set(v) { field = v; requestLayout(); build(); invalidate() }
    /** 0 = خاموش، 1 = یک‌بار، 2 = کپس‌لاک */
    var shift = 0
        set(v) { field = v; invalidate() }

    // ذره‌بین: کلمه‌ی زیر مکان‌نما درشت نشان داده می‌شود
    var onLoupeLetter: ((Int) -> Unit)? = null
    var onLoupePick: ((String) -> Unit)? = null
    var onLoupeClose: (() -> Unit)? = null
    var onLoupeWord: ((String) -> Unit)? = null
    private var loupeWords: List<String> = emptyList()
    private var loupeWord: String? = null
    private var loupeCursor = -1
    private var loupeSel = -1
    private var loupeCands: List<String> = emptyList()

    fun setLoupe(word: String?, cursor: Int = -1) {
        val changed = (loupeWord != null) != (word != null)
        loupeWord = word; loupeCursor = cursor; loupeSel = -1; loupeCands = emptyList(); loupeWords = emptyList()
        if (changed) requestLayout()
        build(); invalidate()
    }

    fun setLoupeWords(words: List<String>) { loupeWords = words; invalidate() }

    fun setLoupeCandidates(sel: Int, cands: List<String>) { loupeSel = sel; loupeCands = cands; invalidate() }

    /** متن راست‌به‌چپ (فارسی، عربی، عبری) یا چپ‌به‌راست (انگلیسی)؟ */
    private fun rtlText(s: String) = s.any { it.code in 0x0590..0x08FF }

    private fun handleLoupeTap(x: Float, y: Float) {
        val w = loupeWord ?: return
        val d = density
        val rowH = 42 * d
        if (y < rowH) {
            if (x < 48 * d) { onLoupeClose?.invoke(); return }
            val n = w.length
            val cw = min(44 * d, (width - 56 * d) / n)
            val left = width / 2f - cw * n / 2f
            val raw = Math.floor(((x - left) / cw).toDouble()).toInt()
            val i = if (rtlText(w)) n - 1 - raw else raw
            if (raw in 0 until n) onLoupeLetter?.invoke(i)
        } else if (loupeCands.isNotEmpty()) {
            val m = loupeCands.size
            val cw = min(52 * d, (width - 16 * d) / m)
            val left = width / 2f - cw * m / 2f
            val raw = Math.floor(((x - left) / cw).toDouble()).toInt()
            val k = if (rtlText(w)) m - 1 - raw else raw
            if (raw in 0 until m) onLoupePick?.invoke(loupeCands[k])
        } else if (loupeWords.isNotEmpty()) {
            val m = loupeWords.size
            val cw = min(110 * d, (width - 16 * d) / m)
            val left = width / 2f - cw * m / 2f
            val raw = Math.floor(((x - left) / cw).toDouble()).toInt()
            val k = if (rtlText(w)) m - 1 - raw else raw
            if (raw in 0 until m) onLoupeWord?.invoke(loupeWords[k])
        }
    }

    private val rkeys = ArrayList<RKey>()
    private val density = resources.displayMetrics.density
    private val stripH get() = when {
        loupeWord != null -> 84 * density
        store.suggest && store.sugPos == 0 -> 52 * density
        else -> 6 * density
    }
    /** ردیف پیشنهاد «نزدیک شست»: درست بالای ردیف پایین */
    private val chipH get() = if (store.suggest && store.sugPos == 1 && layer <= 1) 44 * density else 0f
    private var chipTop = 0f
    private fun inChipRow(y: Float) = loupeWord == null && chipH > 0f && y >= chipTop && y < chipTop + chipH

    private var bgC = 0; private var keyC = 0; private var spC = 0; private var txtC = 0; private var accC = 0
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER }
    private val handler = Handler(Looper.getMainLooper())

    private var pressed: RKey? = null
    private var sugTap = false

    // فشار طولانی (حرف‌های جانبی مثل ژ، ئ، آ)
    private var popActive = false
    private var popKeys: List<String> = emptyList()
    private val popRects = ArrayList<RectF>()
    private var popSel = 0
    private var popOut: List<String> = emptyList()
    private var downX = 0f
    private var downY = 0f
    private var tx = 0f
    private var ty = 0f
    private var longDone = false

    init { reload() }

    private fun displayLabel(d: KeyDef): String = when {
        d.kind == Kind.SHIFT -> if (shift == 2) "⇪" else "⇧"
        layer == 1 && shift > 0 && d.learn -> d.label.uppercase()
        d.kind == Kind.SPACE && store.suggest && store.sugPos == 2 && loupeWord == null && suggestions.isNotEmpty() -> suggestions[0]
        else -> d.label
    }

    private fun visibleRows(): List<List<KeyDef>> {
        val rows = Layouts.layers[layer]
        return if (layer <= 1 && !store.numRow) rows.drop(1) else rows
    }

    fun reload() {
        when (store.theme) {
            1 -> { bgC = 0xFFE9EBF0.toInt(); keyC = 0xFFFFFFFF.toInt(); spC = 0xFFD3D7E0.toInt(); txtC = 0xFF1B1E26.toInt() }
            2 -> { bgC = 0xFF000000.toInt(); keyC = 0xFF15161A.toInt(); spC = 0xFF0C0D10.toInt(); txtC = 0xFFECEFF4.toInt() }
            else -> { bgC = 0xFF14161C.toInt(); keyC = 0xFF252932.toInt(); spC = 0xFF1D2028.toInt(); txtC = 0xFFECEFF4.toInt() }
        }
        accC = Palette.accents[store.accent.coerceIn(0, Palette.accents.size - 1)]
        requestLayout(); build(); invalidate()
    }

    override fun onMeasure(w: Int, h: Int) {
        val width = MeasureSpec.getSize(w)
        val height = (stripH + chipH + store.keyDp * density * visibleRows().size + 8 * density).toInt()
        setMeasuredDimension(width, height)
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) { build() }

    // ---------- رشد کلیدها بر اساس یادگیری ----------
    private val demoLean = mapOf(
        "ک" to (0.8f to 0.5f), "ر" to (-0.7f to 0.6f), "ه" to (0.6f to -0.6f),
        "س" to (-0.8f to -0.4f), "ت" to (0.9f to 0.2f), "ب" to (-0.5f to 0.8f)
    )

    /** جهت و مقدار کشیدگی کلید (هر کدام بین ۱- و ۱) */
    private fun leanOf(k: RKey): Pair<Float, Float> {
        if (!k.def.learn) return 0f to 0f
        if (demo) demoLean[k.def.label]?.let { return it }
        val s = store.keys[k.def.label] ?: return 0f to 0f
        if (s.hits < 10) return 0f to 0f
        val conf = min(1f, s.hits / 40f)
        return (s.mx / 0.25f).coerceIn(-1f, 1f) * conf to (s.my / 0.25f).coerceIn(-1f, 1f) * conf
    }

    private fun rateF(d: KeyDef) = min(1f, store.errorRate(d.label) * 5f)
    private fun wScale(d: KeyDef): Float =
        if (d.learn) store.sizeScale(d.label) else 1f
    private fun hScale(d: KeyDef): Float =
        if (store.grow && d.learn) 1f + 0.25f * min(2f, store.growPct / 100f) * rateF(d) else 1f

    /** بعد از هر یادگیری، چیدمان دوباره محاسبه می‌شود */
    fun rebuild() { build(); invalidate() }

    private fun build() {
        rkeys.clear()
        if (width == 0 || height == 0) return
        val rows = visibleRows()
        val pad = 3 * density
        val avail = height - stripH - chipH - 2 * density - pad
        val rs = rows.map { 1f }          // همه‌ی ردیف‌ها همیشه هم‌ارتفاع می‌مانند
        val rsum = rs.sum()
        var y = stripH + 2 * density
        val gs = store.growPct / 100f
        for ((ri, row) in rows.withIndex()) {
            val rowH = avail * rs[ri] / rsum
            if (ri == rows.size - 1 && chipH > 0f) { chipTop = y; y += chipH }
            val ws = row.map { wScale(it) }
            var extra = 0f
            row.forEachIndexed { i, k -> extra += k.weight * (ws[i] - 1f) }
            val maxExtra = (0.20f * gs).coerceAtMost(0.4f) * row.sumOf { it.weight.toDouble() }.toFloat()
            val g = if (extra > maxExtra) maxExtra / extra else 1f
            val eff = row.mapIndexed { i, k -> k.weight * (1f + (ws[i] - 1f) * g) }
            val unit = (width - 2 * pad) / eff.sum()
            var x = pad
            row.forEachIndexed { i, k ->
                val kw = unit * eff[i]
                rkeys.add(RKey(k, RectF(x, y, x + kw, y + rowH)))
                x += kw
            }
            y += rowH
        }
    }

    fun cellOf(label: String): RKey? = rkeys.firstOrNull { it.def.learn && it.def.label == label }

    // ---------- تشخیص کلید با مدل گاوسی شخصی ----------
    private fun resolve(x: Float, y: Float): RKey? {
        val inside = rkeys.firstOrNull { it.r.contains(x, y) }
        if (inside != null && !inside.def.learn) return inside
        val gb = store.globalBias()
        val cands = ArrayList<Pair<RKey, Float>>()
        for (k in rkeys) {
            if (!k.def.learn) continue
            val dx = (x - k.cx) / k.w
            val dy = (y - k.cy) / k.h
            if (abs(dx) > 0.8f || abs(dy) > 0.7f) continue
            var mx = 0f; var my = 0f; var sx = 0.45f; var sy = 0.45f
            if (store.adaptive && k.def.learn) {
                val s = store.stat(k.def.label)
                if (s.errors < 2) { mx = gb.first; my = gb.second }
                else { mx = s.mx.coerceIn(-0.3f, 0.3f); my = s.my.coerceIn(-0.3f, 0.3f) }
                sx = s.sx; sy = s.sy
            }
            val ex = (dx - mx) / sx
            val ey = (dy - my) / sy
            // حرف پرکاربردتر (مثل «ر») در مرز با حرف کم‌کاربرد (مثل «ذ») کمی شانس بیشتری دارد
            val prior = -0.2f * ln(Layouts.freqOf(k.def.label) / 3f)
            // حرف قبلی کلمه: بعد از «قنا» حرف «ر» از «ذ» محتمل‌تر است (از روی کلمه‌های خودت)
            val cw = currentWord
            val ctx = if (store.adaptive && cw.isNotEmpty() && cw.last().isLetter() && k.def.label.length == 1)
                -0.15f * ln(store.nextLetterProb(cw.last(), k.def.label) * 35f) else 0f
            cands.add(k to (0.5f * (ex * ex + ey * ey) + ln(sx * sy) + prior + ctx))
        }
        if (cands.isEmpty()) return rkeys.minByOrNull { hypot(x - it.cx, y - it.cy) }
        cands.sortBy { it.second }
        if (store.adaptive && cands.size > 1 && currentWord.isNotEmpty() &&
            cands[1].second - cands[0].second < 0.9f
        ) {
            val a = cands[0]; val b = cands[1]
            if (a.first.def.learn && b.first.def.learn) {
                val wa = store.prefixWeight(currentWord + a.first.def.out)
                val wb = store.prefixWeight(currentWord + b.first.def.out)
                val sa = a.second - 0.45f * ln(1f + wa)
                val sb = b.second - 0.45f * ln(1f + wb)
                if (sb < sa) return b.first
            }
        }
        return cands[0].first
    }

    // ---------- لمس ----------
    private val repeat = object : Runnable {
        override fun run() {
            val p = pressed ?: return
            if (p.def.kind == Kind.BACKSPACE) {
                onKey?.invoke(p.def, 0f, 0f, 0f, 0f)
                handler.postDelayed(this, 45)
            }
        }
    }

    private val longPress = Runnable {
        val p = pressed ?: return@Runnable
        if (p.def.kind == Kind.SPACE && store.suggest && store.sugPos == 2 && suggestions.isNotEmpty()) {
            longDone = true; buzz(); onSuggestion?.invoke(suggestions[0]); return@Runnable
        }
        if (p.def.label == "۱۲۳" || p.def.label == "123") {      // نگه‌داشتن: صفحه‌ی فقط اعداد
            longDone = true; buzz()
            onKey?.invoke(KeyDef("🔢", Kind.LAYER, target = 8, emoji = true), 0f, 0f, 0f, 0f)
            return@Runnable
        }
        if (p.def.label == "🌐") { longDone = true; buzz(); onPicker?.invoke(); return@Runnable }
        val list: List<String> = when {
            p.def.label == "😊" -> listOf("⚙")            // زیر دکمه‌ی ایموجی: تنظیمات
            p.def.kind == Kind.CHAR -> Layouts.alts[p.def.label.lowercase()]
            else -> null
        } ?: return@Runnable
        popOut = list.map { if (layer == 1 && shift > 0) it.uppercase() else it }
        popKeys = popOut.map { popDisplay(it) }
        val cw = maxOf(p.w, 44 * density)
        val ch = p.h * 1.05f
        val total = cw * popKeys.size
        val left = (p.cx - total / 2).coerceIn(2 * density, maxOf(2 * density, width - total - 2 * density))
        val top = (p.r.top - ch - 6 * density).coerceAtLeast(0f)
        popRects.clear()
        for (i in popKeys.indices) popRects.add(RectF(left + i * cw, top, left + (i + 1) * cw, top + ch))
        popSel = 0
        popActive = true
        buzz()
        invalidate()
    }

    private fun popDisplay(s: String): String =
        if (s.isNotEmpty() && Character.getType(s[0]) == Character.NON_SPACING_MARK.toInt()) "ـ" + s else s

    private fun buzz() {
        if (store.haptic) performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
    }

    private fun selectPopup(x: Float) {
        var best = 0
        var bd = Float.MAX_VALUE
        for (i in popRects.indices) {
            val dd = abs(popRects[i].centerX() - x)
            if (dd < bd) { bd = dd; best = i }
        }
        if (best != popSel) { popSel = best; invalidate() }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                if (e.y < stripH || inChipRow(e.y)) { sugTap = true; return true }
                sugTap = false
                popActive = false
                handler.removeCallbacks(longPress)
                pressed = resolve(e.x, e.y)
                downX = e.x; downY = e.y; tx = e.x; ty = e.y; longDone = false
                buzz()
                val p = pressed
                if (p != null) {
                    if (p.def.kind == Kind.BACKSPACE) {
                        onKey?.invoke(p.def, 0f, 0f, 0f, 0f)
                        handler.postDelayed(repeat, 380)
                    } else if ((p.def.kind == Kind.CHAR && Layouts.alts.containsKey(p.def.label.lowercase())) || p.def.label == "🌐" || p.def.label == "😊" || p.def.label == "۱۲۳" || p.def.label == "123" ||
                        (p.def.kind == Kind.SPACE && store.suggest && store.sugPos == 2 && suggestions.isNotEmpty())) {
                        handler.postDelayed(longPress, 380)
                    }
                }
                invalidate()
            }
            MotionEvent.ACTION_MOVE -> {
                if (popActive) { selectPopup(e.x); return true }
                val p = pressed
                if (!sugTap && p != null && p.def.kind != Kind.BACKSPACE &&
                    hypot(e.x - downX, e.y - downY) > 0.35f * p.h
                ) {
                    // لرزش کوچک انگشت کلید را عوض نمی‌کند؛ فقط حرکت واقعی
                    val k = resolve(e.x, e.y)
                    if (k !== p) { pressed = k; tx = e.x; ty = e.y; handler.removeCallbacks(longPress); invalidate() }
                }
            }
            MotionEvent.ACTION_UP -> {
                handler.removeCallbacks(repeat)
                handler.removeCallbacks(longPress)
                if (longDone) {
                    longDone = false
                } else if (popActive) {
                    val alt = popOut.getOrNull(popSel)
                    popActive = false
                    if (alt == "⚙") onSettings?.invoke()
                    else if (alt != null) onKey?.invoke(KeyDef(alt, Kind.CHAR, out = alt, alt = true), 0f, 0f, e.x, e.y)
                } else if (sugTap) {
                    sugTap = false
                    if (loupeWord != null) {
                        handleLoupeTap(e.x, e.y)
                    } else {
                        val raw = (e.x / (width / 3f)).toInt().coerceIn(0, 2)
                        val ltr = suggestions.firstOrNull()?.let { !rtlText(it) } ?: false
                        suggestions.getOrNull(if (ltr) raw else 2 - raw)?.let { onSuggestion?.invoke(it) }
                    }
                } else if (pressed != null) {
                    val k = pressed!!
                    if (k.def.kind != Kind.BACKSPACE) {
                        onKey?.invoke(k.def, (tx - k.cx) / k.w, (ty - k.cy) / k.h, tx, ty)
                    }
                }
                pressed = null
                invalidate()
            }
            MotionEvent.ACTION_CANCEL -> {
                handler.removeCallbacks(repeat); handler.removeCallbacks(longPress)
                pressed = null; sugTap = false; popActive = false; invalidate()
            }
        }
        return true
    }

    // ---------- رسم ----------
    override fun onDraw(c: Canvas) {
        c.drawColor(bgC)
        drawStrip(c)
        if (chipH > 0f && loupeWord == null) drawChips(c, chipTop, chipTop + chipH)
        for (k in rkeys) drawKey(c, k)
        if (popActive) drawPopup(c) else drawBubble(c)
    }

    private fun drawLoupe(c: Canvas) {
        val w = loupeWord ?: return
        val d = density
        val rowH = 42 * d
        paint.style = Paint.Style.FILL
        paint.color = spC
        c.drawRect(0f, 0f, width.toFloat(), stripH, paint)
        val n = w.length
        val cw = min(44 * d, (width - 56 * d) / n)
        val leftEdge = width / 2f - cw * n / 2f
        val rtl = rtlText(w)
        for (i in 0 until n) {
            val cx = leftEdge + ((if (rtl) n - 1 - i else i) + 0.5f) * cw
            val r = RectF(cx - cw / 2 + 2 * d, 4 * d, cx + cw / 2 - 2 * d, rowH - 2 * d)
            paint.style = Paint.Style.FILL
            paint.color = if (i == loupeSel) accC else keyC
            c.drawRoundRect(r, 8 * d, 8 * d, paint)
            text.color = if (i == loupeSel) Color.WHITE else txtC
            text.textSize = rowH * 0.55f
            c.drawText(w[i].toString(), cx, r.centerY() - (text.ascent() + text.descent()) / 2f, text)
        }
        if (loupeCursor in 0..n) {
            // جای مکان‌نما: یک خط باریک بین حرف‌ها (نه یک حرف انتخاب‌شده)
            val cxl = leftEdge + (if (rtl) n - loupeCursor else loupeCursor) * cw
            paint.style = Paint.Style.FILL
            paint.color = accC
            c.drawRoundRect(RectF(cxl - 1.5f * d, 6 * d, cxl + 1.5f * d, rowH - 4 * d), 2 * d, 2 * d, paint)
        }
        text.color = txtC
        text.textSize = 20 * d
        c.drawText("✕", 24 * d, rowH / 2 - (text.ascent() + text.descent()) / 2f, text)
        val y2 = rowH + (stripH - rowH) / 2f
        if (loupeCands.isEmpty() && loupeWords.isNotEmpty()) {
            drawLoupeWords(c, w, rowH)
        } else if (loupeCands.isEmpty()) {
            text.color = Color.argb(150, Color.red(txtC), Color.green(txtC), Color.blue(txtC))
            text.textSize = 13 * d
            c.drawText(if (store.isFa) "یک حرف را لمس کن تا بتوانی عوضش کنی" else "Tap a letter to change it",
                width / 2f, y2 - (text.ascent() + text.descent()) / 2f, text)
        } else {
            val m = loupeCands.size
            val cw2 = min(52 * d, (width - 16 * d) / m)
            val left2 = width / 2f - cw2 * m / 2f
            for (k in 0 until m) {
                val cx = left2 + ((if (rtl) m - 1 - k else k) + 0.5f) * cw2
                val r = RectF(cx - cw2 / 2 + 2 * d, rowH + 2 * d, cx + cw2 / 2 - 2 * d, stripH - 4 * d)
                paint.style = Paint.Style.FILL
                paint.color = keyC
                c.drawRoundRect(r, 8 * d, 8 * d, paint)
                text.color = txtC
                text.textSize = (stripH - rowH) * 0.5f
                c.drawText(loupeCands[k], cx, r.centerY() - (text.ascent() + text.descent()) / 2f, text)
            }
        }
    }

    private fun drawChips(c: Canvas, top: Float, bottom: Float) {
        if (suggestions.isEmpty()) return
        val slot = width / 3f
        val ltr = !rtlText(suggestions[0])
        for (i in 0..2) {
            val s = suggestions.getOrNull(i) ?: continue
            val cx = if (ltr) (i + 0.5f) * slot else width - (i + 0.5f) * slot
            val r = RectF(cx - slot / 2 + 4 * density, top + 6 * density, cx + slot / 2 - 4 * density, bottom - 6 * density)
            paint.style = Paint.Style.FILL
            paint.color = keyC
            c.drawRoundRect(r, 10 * density, 10 * density, paint)
            text.color = if (i == 0) accC else txtC
            text.textSize = 20 * density
            val tw = text.measureText(s)
            if (tw > r.width() - 10 * density) text.textSize = 20 * density * (r.width() - 10 * density) / tw
            c.drawText(s, cx, r.centerY() - (text.ascent() + text.descent()) / 2f, text)
        }
    }

    private fun drawLoupeWords(c: Canvas, w: String, rowH: Float) {
        val d = density
        val m = loupeWords.size
        val cw = min(110 * d, (width - 16 * d) / m)
        val left = width / 2f - cw * m / 2f
        val rtl = rtlText(w)
        for (k in 0 until m) {
            val cx = left + ((if (rtl) m - 1 - k else k) + 0.5f) * cw
            val r = RectF(cx - cw / 2 + 3 * d, rowH + 2 * d, cx + cw / 2 - 3 * d, stripH - 4 * d)
            paint.style = Paint.Style.FILL
            paint.color = keyC
            c.drawRoundRect(r, 10 * d, 10 * d, paint)
            text.color = if (k == 0) accC else txtC
            text.textSize = 20 * d
            val tw = text.measureText(loupeWords[k])
            if (tw > r.width() - 10 * d) text.textSize = 20 * d * (r.width() - 10 * d) / tw
            c.drawText(loupeWords[k], cx, r.centerY() - (text.ascent() + text.descent()) / 2f, text)
        }
    }

    private fun drawStrip(c: Canvas) {
        if (loupeWord != null) { drawLoupe(c); return }
        if (store.suggest && store.sugPos == 0) drawChips(c, 0f, stripH)
    }

    /** شکل واقعی و غیرهندسی کلید زنده: منحنی نرمی که به سمت انگشت کشیده شده */
    private fun blobPath(r: RectF, sx: Float, sy: Float, seed: Int): Path {
        val n = 28
        val a = r.width() / 2f
        val b = r.height() / 2f
        val mag = minOf(1f, kotlin.math.hypot(sx, sy))
        val phi = atan2(sy, sx)
        val pts = FloatArray(n * 2)
        for (i in 0 until n) {
            val th = (2.0 * Math.PI * i / n).toFloat()
            val ct = cos(th)
            val sn = sin(th)
            val rb = (abs(ct / a).pow(3f) + abs(sn / b).pow(3f)).pow(-1f / 3f)
            val f = 0.88f * (1f + 0.16f * (ct * sx + sn * sy) + 0.08f * mag * cos(2f * (th - phi))) +
                0.03f * sin(3f * th + (seed % 7))
            pts[i * 2] = (rb * f * ct).coerceIn(-a, a)
            pts[i * 2 + 1] = (rb * f * sn).coerceIn(-b, b)
        }
        fun p(i: Int, k: Int) = pts[(((i % n) + n) % n) * 2 + k]
        val cx = r.centerX()
        val cy = r.centerY()
        val path = Path()
        path.moveTo(cx + p(0, 0), cy + p(0, 1))
        for (i in 0 until n) {
            path.cubicTo(
                cx + p(i, 0) + (p(i + 1, 0) - p(i - 1, 0)) / 6f, cy + p(i, 1) + (p(i + 1, 1) - p(i - 1, 1)) / 6f,
                cx + p(i + 1, 0) - (p(i + 2, 0) - p(i, 0)) / 6f, cy + p(i + 1, 1) - (p(i + 2, 1) - p(i, 1)) / 6f,
                cx + p(i + 1, 0), cy + p(i + 1, 1)
            )
        }
        path.close()
        return path
    }

    private fun drawKey(c: Canvas, k: RKey) {
        val hg = 1.3f * density
        val gs = store.growPct / 100f
        val grown = if (k.def.learn && store.grow) ((store.sizeScale(k.def.label) - 1f) / (0.30f * gs)).coerceIn(0f, 1f) else 0f
        val vg = (0.8f + 1.8f * (1f - grown)) * density      // کلید پراشتباه، کمی بلندتر دیده می‌شود
        val r = RectF(k.r)
        r.inset(hg, vg)

        val blob = store.liveShow && k.def.learn
        val path = if (blob) {
            val (sx, sy) = leanOf(k)
            blobPath(r, sx, sy, k.def.label.hashCode())
        } else {
            Path().apply { addRoundRect(r, 7 * density, 7 * density, Path.Direction.CW) }
        }

        val isP = pressed === k && !popActive
        val special = k.def.kind != Kind.CHAR || (!k.def.learn && !k.def.emoji && k.def.label.length > 1)
        paint.style = Paint.Style.FILL
        paint.color = when {
            isP -> accC
            k.def.kind == Kind.ENTER -> accC
            k.def.kind == Kind.SHIFT && shift > 0 -> accC
            special -> spC
            else -> keyC
        }
        c.drawPath(path, paint)

        if (store.heat && k.def.learn && !isP) {
            val er = min(1f, store.errorRate(k.def.label) * 3f)
            paint.color = Color.argb((er * 130).toInt(), Color.red(accC), Color.green(accC), Color.blue(accC))
            c.drawPath(path, paint)
            val s = store.stat(k.def.label)
            paint.color = Color.argb(200, Color.red(accC), Color.green(accC), Color.blue(accC))
            c.drawCircle(k.cx + s.mx * k.w, k.cy + s.my * k.h, 2.5f * density, paint)
        }

        val shown = displayLabel(k.def)
        val sugOnSpace = k.def.kind == Kind.SPACE && shown != k.def.label
        text.textSize = k.h * when {
            sugOnSpace -> 0.34f
            k.def.emoji && k.def.label.length > 3 -> 0.30f
            k.def.emoji -> 0.46f
            k.def.label.length > 1 -> 0.26f
            else -> 0.38f
        }
        text.color = when {
            isP || k.def.kind == Kind.ENTER || (k.def.kind == Kind.SHIFT && shift > 0) -> Color.WHITE
            sugOnSpace -> accC
            else -> txtC
        }
        if (sugOnSpace) {
            val tw = text.measureText(shown)
            if (tw > r.width() - 12 * density) text.textSize = text.textSize * (r.width() - 12 * density) / tw
        }
        val dy = -(text.ascent() + text.descent()) / 2f
        c.drawText(shown, r.centerX(), r.centerY() + dy, text)
    }

    private fun drawBubble(c: Canvas) {
        val p = pressed ?: return
        if (!store.preview || p.def.kind != Kind.CHAR || p.def.emoji) return
        val bw = p.w * 1.5f
        val bh = p.h * 1.15f
        val left = (p.cx - bw / 2).coerceIn(2 * density, width - bw - 2 * density)
        val top = (p.r.top - bh - 4 * density).coerceAtLeast(0f)
        val r = RectF(left, top, left + bw, top + bh)
        paint.style = Paint.Style.FILL
        paint.color = accC
        c.drawRoundRect(r, 12 * density, 12 * density, paint)
        text.color = Color.WHITE
        text.textSize = p.h * 0.6f
        val dy = -(text.ascent() + text.descent()) / 2f
        c.drawText(displayLabel(p.def), r.centerX(), r.centerY() + dy, text)
    }

    private fun drawPopup(c: Canvas) {
        if (popRects.isEmpty()) return
        val all = RectF(popRects.first().left, popRects.first().top, popRects.last().right, popRects.first().bottom)
        all.inset(-3 * density, -3 * density)
        paint.style = Paint.Style.FILL
        paint.color = spC
        c.drawRoundRect(all, 12 * density, 12 * density, paint)
        for (i in popRects.indices) {
            val r = RectF(popRects[i])
            r.inset(2 * density, 2 * density)
            paint.color = if (i == popSel) accC else keyC
            c.drawRoundRect(r, 9 * density, 9 * density, paint)
            text.color = if (i == popSel) Color.WHITE else txtC
            text.textSize = r.height() * 0.5f
            val dy = -(text.ascent() + text.descent()) / 2f
            c.drawText(popKeys[i], r.centerX(), r.centerY() + dy, text)
        }
    }
}
