package com.adaptivekb

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.math.sqrt

/** مدل لمس هر کلید: مرکز واقعی لمس (نسبت به مرکز کلید) و پراکندگی */
class KeyStat(
    var mx: Float = 0f, var my: Float = 0f,
    var sx: Float = 0.42f, var sy: Float = 0.42f,
    var hits: Int = 0, var errors: Int = 0
)

class Store private constructor(ctx: Context) {
    private val sp = ctx.applicationContext.getSharedPreferences("akb", Context.MODE_PRIVATE)
    val keys = HashMap<String, KeyStat>()
    val confusion = HashMap<String, Int>()   // "قصد>خورده"
    val words = HashMap<String, Int>()
    private var unsaved = 0

    // ---------- تنظیمات ----------
    var accent: Int get() = sp.getInt("accent", 0); set(v) { sp.edit().putInt("accent", v).apply() }
    var theme: Int get() = sp.getInt("theme", 0); set(v) { sp.edit().putInt("theme", v).apply() }
    var keyDp: Int get() = sp.getInt("keyDp", 52); set(v) { sp.edit().putInt("keyDp", v).apply() }
    var adaptive: Boolean get() = sp.getBoolean("adaptive", true); set(v) { sp.edit().putBoolean("adaptive", v).apply() }
    var grow: Boolean get() = sp.getBoolean("grow", true); set(v) { sp.edit().putBoolean("grow", v).apply() }
    var heat: Boolean get() = sp.getBoolean("heat", false); set(v) { sp.edit().putBoolean("heat", v).apply() }
    var haptic: Boolean get() = sp.getBoolean("haptic", true); set(v) { sp.edit().putBoolean("haptic", v).apply() }
    var preview: Boolean get() = sp.getBoolean("preview", true); set(v) { sp.edit().putBoolean("preview", v).apply() }
    var suggest: Boolean get() = sp.getBoolean("suggest", true); set(v) { sp.edit().putBoolean("suggest", v).apply() }

    var lang: Int get() = sp.getInt("lang", -1); set(v) { sp.edit().putInt("lang", v).apply() }
    val isFa: Boolean get() = if (lang == -1) Locale.getDefault().language == "fa" else lang == 0

    init { load() }

    fun stat(k: String): KeyStat = keys.getOrPut(k) { KeyStat() }

    fun learnSample(label: String, nx: Float, ny: Float, alpha: Float) {
        val s = stat(label)
        s.mx += alpha * (nx - s.mx)
        s.my += alpha * (ny - s.my)
        val dx = nx - s.mx
        val dy = ny - s.my
        s.sx = sqrt((1 - alpha) * s.sx * s.sx + alpha * dx * dx).coerceIn(0.30f, 0.70f)
        s.sy = sqrt((1 - alpha) * s.sy * s.sy + alpha * dy * dy).coerceIn(0.30f, 0.70f)
        s.mx = s.mx.coerceIn(-0.45f, 0.45f)
        s.my = s.my.coerceIn(-0.45f, 0.45f)
        touched()
    }

    fun strokeCommitted(label: String) {
        stat(label).hits++
        addDay(1, 0)
    }

    fun recordError(intended: String, hit: String) {
        stat(intended).errors++
        val k = "$intended>$hit"
        confusion[k] = (confusion[k] ?: 0) + 1
        addDay(0, 1)
    }

    fun errorRate(label: String): Float {
        val s = keys[label] ?: return 0f
        val n = s.hits + s.errors
        return if (n < 6) 0f else s.errors.toFloat() / n
    }

    // ---------- کلمات ----------
    fun learnWord(w: String) {
        if (w.length < 2) return
        words[w] = (words[w] ?: 0) + 1
        if (words.size > 6000) words.entries.removeAll { it.value <= 1 }
        touched()
    }

    fun prefixWeight(p: String): Int {
        var t = 0
        for ((w, c) in words) if (w.startsWith(p)) t += c
        return t
    }

    fun suggestions(p: String, n: Int = 3): List<String> =
        words.entries.filter { it.key.startsWith(p) && it.key != p }
            .sortedByDescending { it.value }.take(n).map { it.key }

    // ---------- آمار روزانه ----------
    private val fmt = SimpleDateFormat("yyyyMMdd", Locale.US)
    private fun addDay(s: Int, c: Int) {
        val key = "d_" + fmt.format(Date())
        val parts = (sp.getString(key, "0,0") ?: "0,0").split(",")
        val ns = (parts.getOrNull(0)?.toIntOrNull() ?: 0) + s
        val nc = (parts.getOrNull(1)?.toIntOrNull() ?: 0) + c
        sp.edit().putString(key, "$ns,$nc").apply()
        touched()
    }

    /** ۷ روز اخیر: (تعداد ضربه، تعداد اصلاح، شماره روز ماه) */
    fun last7(): List<Triple<Int, Int, Int>> {
        val out = ArrayList<Triple<Int, Int, Int>>()
        for (i in 6 downTo 0) {
            val cal = Calendar.getInstance()
            cal.add(Calendar.DAY_OF_YEAR, -i)
            val parts = (sp.getString("d_" + fmt.format(cal.time), "0,0") ?: "0,0").split(",")
            out.add(Triple(parts[0].toIntOrNull() ?: 0, parts.getOrNull(1)?.toIntOrNull() ?: 0, cal.get(Calendar.DAY_OF_MONTH)))
        }
        return out
    }

    // ---------- ذخیره/بارگذاری ----------
    private fun touched() { if (++unsaved >= 25) save() }

    fun save() {
        unsaved = 0
        try {
            val o = JSONObject()
            val ks = JSONObject()
            for ((k, s) in keys) {
                ks.put(k, JSONArray().put(s.mx.toDouble()).put(s.my.toDouble()).put(s.sx.toDouble())
                    .put(s.sy.toDouble()).put(s.hits).put(s.errors))
            }
            o.put("keys", ks)
            o.put("conf", JSONObject(confusion as Map<*, *>))
            o.put("words", JSONObject(words as Map<*, *>))
            sp.edit().putString("data", o.toString()).apply()
        } catch (_: Exception) {}
    }

    private fun load() {
        val raw = sp.getString("data", null) ?: return
        try {
            val o = JSONObject(raw)
            o.optJSONObject("keys")?.let { ks ->
                ks.keys().forEach { k ->
                    val a = ks.getJSONArray(k)
                    keys[k] = KeyStat(a.getDouble(0).toFloat(), a.getDouble(1).toFloat(),
                        a.getDouble(2).toFloat(), a.getDouble(3).toFloat(), a.getInt(4), a.getInt(5))
                }
            }
            o.optJSONObject("conf")?.let { c -> c.keys().forEach { confusion[it] = c.getInt(it) } }
            o.optJSONObject("words")?.let { w -> w.keys().forEach { words[it] = w.getInt(it) } }
        } catch (_: Exception) {}
    }

    fun resetLearning() {
        keys.clear(); confusion.clear(); words.clear()
        val e = sp.edit()
        for (k in sp.all.keys) if (k.startsWith("d_")) e.remove(k)
        e.remove("data").apply()
    }

    companion object {
        @Volatile private var inst: Store? = null
        fun get(ctx: Context): Store = inst ?: synchronized(this) {
            inst ?: Store(ctx).also { inst = it }
        }
    }
}
