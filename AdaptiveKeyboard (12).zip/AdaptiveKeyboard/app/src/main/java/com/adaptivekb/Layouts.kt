package com.adaptivekb

enum class Kind { CHAR, BACKSPACE, SPACE, ENTER, LAYER, SHIFT }

data class KeyDef(
    val label: String,
    val kind: Kind = Kind.CHAR,
    val out: String = label,
    val weight: Float = 1f,
    val target: Int = 0,
    val emoji: Boolean = false,
    val alt: Boolean = false
) {
    /** فقط کلیدهای تک‌حرفی یاد گرفته می‌شوند (نه ایموجی و نه حرف‌های فشار طولانی) */
    val learn: Boolean get() = kind == Kind.CHAR && label.length == 1 && out == label && !emoji && !alt
}

object Palette {
    val accents = intArrayOf(
        0xFF7C6CF0.toInt(), 0xFF1FC8A0.toInt(), 0xFFFF6B81.toInt(),
        0xFF3B9CFF.toInt(), 0xFFFFB02E.toInt(), 0xFFE056C1.toInt()
    )
}

object Layouts {
    private fun row(s: String) = s.split(" ").map { KeyDef(it) }
    private val bs = KeyDef("⌫", Kind.BACKSPACE, weight = 1.5f)

    private val marks = listOf(
        "\u064E", "\u064F", "\u0650", "\u064B", "\u064C", "\u064D", "\u0651", "\u0652", "\u0670", "\u0653"
    )

    /** حرف‌های فشار طولانی (مثل کیبورد گوگل) */
    val alts: Map<String, List<String>> = mapOf(
        "ا" to listOf("آ", "ء", "أ", "إ"),
        "ی" to listOf("ئ", "ي"),
        "و" to listOf("ؤ"),
        "ز" to listOf("ژ"),
        "ه" to listOf("ة", "ۀ"),
        "ک" to listOf("ك"),
        "ج" to listOf("چ"),
        "،" to listOf("؛", "؟", "!", ":"),
        "." to listOf("…", "!", "؟", ":"),
        "نیم" to marks,
        "a" to listOf("à", "á", "â", "ä", "ã"),
        "e" to listOf("è", "é", "ê", "ë"),
        "i" to listOf("ì", "í", "î", "ï"),
        "o" to listOf("ò", "ó", "ô", "ö"),
        "u" to listOf("ù", "ú", "û", "ü"),
        "n" to listOf("ñ"), "c" to listOf("ç"), "s" to listOf("ß")
    )

    // لایه ۰: فارسی (مثل کیبورد گوگل؛ چ پایین، ژ و ئ با فشار طولانی)
    private val fa = listOf(
        row("۱ ۲ ۳ ۴ ۵ ۶ ۷ ۸ ۹ ۰"),
        row("ض ص ث ق ف غ ع ه خ ح ج"),
        row("ش س ی ب ل ا ت ن م ک گ"),
        row("ظ ط ز ر ذ د پ و چ") + bs,
        listOf(
            KeyDef("۱۲۳", Kind.LAYER, weight = 1.3f, target = 2),
            KeyDef("😊", Kind.LAYER, weight = 1.1f, target = 3, emoji = true),
            KeyDef("🌐", Kind.LAYER, weight = 1.1f, target = 1, emoji = true),
            KeyDef("فارسی", Kind.SPACE, weight = 5.0f),
            KeyDef("نیم", Kind.CHAR, out = "\u200c", weight = 1.1f),
            KeyDef("."),
            KeyDef("↵", Kind.ENTER, weight = 1.3f)
        )
    )

    // لایه ۱: انگلیسی
    private val en = listOf(
        row("1 2 3 4 5 6 7 8 9 0"),
        row("q w e r t y u i o p"),
        row("a s d f g h j k l"),
        listOf(KeyDef("⇧", Kind.SHIFT, weight = 1.5f)) + row("z x c v b n m") + bs,
        listOf(
            KeyDef("۱۲۳", Kind.LAYER, weight = 1.3f, target = 2),
            KeyDef("😊", Kind.LAYER, weight = 1.1f, target = 3, emoji = true),
            KeyDef("🌐", Kind.LAYER, weight = 1.1f, target = 0, emoji = true),
            KeyDef(","),
            KeyDef("English", Kind.SPACE, weight = 4.2f),
            KeyDef("."),
            KeyDef("↵", Kind.ENTER, weight = 1.3f)
        )
    )

    // لایه ۲: اعداد و نمادها
    private val sym = listOf(
        row("1 2 3 4 5 6 7 8 9 0"),
        row("! : ؛ ، ( ) « » - _ /"),
        row("@ # * + = % & \" ' ~"),
        row("€ ٪ . , < > | ؟ ?") + bs,
        listOf(
            KeyDef("ابج", Kind.LAYER, weight = 1.4f, target = 0),
            KeyDef("😊", Kind.LAYER, weight = 1.1f, target = 3, emoji = true),
            KeyDef("حرکات", Kind.LAYER, weight = 1.6f, target = 7),
            KeyDef("فاصله", Kind.SPACE, weight = 3.6f),
            KeyDef("."),
            KeyDef("↵", Kind.ENTER, weight = 1.4f)
        )
    )

    // لایه‌های ۳ تا ۶: ایموجی
    private val emojiBottom = listOf(
        KeyDef("ابج", Kind.LAYER, weight = 1.6f, target = 0),
        KeyDef("😀", Kind.LAYER, target = 3, emoji = true),
        KeyDef("👍", Kind.LAYER, target = 4, emoji = true),
        KeyDef("❤\uFE0F", Kind.LAYER, target = 5, emoji = true),
        KeyDef("🐱", Kind.LAYER, target = 6, emoji = true),
        KeyDef("⌫", Kind.BACKSPACE, weight = 1.6f)
    )

    private fun emojiPage(s: String): List<List<KeyDef>> =
        s.split(" ").chunked(9).map { r -> r.map { KeyDef(it, emoji = true) } } + listOf(emojiBottom)

    private val e1 = emojiPage("😀 😃 😄 😁 😆 😅 😂 🤣 😊 😇 🙂 😉 😍 🥰 😘 😋 😎 🤩 🥳 😏 😒 😔 😢 😭 😡 🤔 😴")
    private val e2 = emojiPage("👍 👎 👌 ✌\uFE0F 🤞 🤝 👏 🙏 💪 👋 🤚 ✋ 👊 ✊ 🙌 🤲 🖐\uFE0F ☝\uFE0F 👆 👇 👈 👉 🤟 🤘 🤙 💅 🙋")
    private val e3 = emojiPage("❤\uFE0F 🧡 💛 💚 💙 💜 🖤 🤍 💔 ❣\uFE0F 💕 💞 💓 💗 💖 💘 💝 🔥 ✨ ⭐ 🌟 💯 ✅ ❌ ❓ ❗ 🎉")
    private val e4 = emojiPage("🐱 🐶 🐭 🐹 🐰 🦊 🐻 🐼 🐨 🦁 🐯 🐸 🐵 🐔 🐧 🦋 🌹 🌸 🌞 🍎 🍕 🍔 ☕ 🍰 🎂 ⚽ 🚗")

    // لایه ۷: حرکات و حروف صدادار
    private val harakat = listOf(
        marks.map { KeyDef("ـ" + it, out = it, emoji = true) },
        "آ ا و ی ء ئ ؤ أ إ ة ۀ".split(" ").map { KeyDef(it, alt = true) },
        listOf(
            KeyDef("نیم", Kind.CHAR, out = "\u200c", weight = 1.5f),
            KeyDef("ـ", alt = true), KeyDef("،", alt = true),
            KeyDef("؛", alt = true), KeyDef("؟", alt = true), bs
        ),
        listOf(
            KeyDef("ابج", Kind.LAYER, weight = 1.5f, target = 0),
            KeyDef("۱۲۳", Kind.LAYER, weight = 1.3f, target = 2),
            KeyDef("😊", Kind.LAYER, weight = 1.1f, target = 3, emoji = true),
            KeyDef("فاصله", Kind.SPACE, weight = 3.6f),
            KeyDef("↵", Kind.ENTER, weight = 1.4f)
        )
    )

    val layers: List<List<List<KeyDef>>> = listOf(fa, en, sym, e1, e2, e3, e4, harakat)
}
