package com.adaptivekb

import android.content.Context
import android.content.Intent
import android.inputmethodservice.InputMethodService
import android.os.SystemClock
import android.text.InputType
import android.view.View
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputConnection
import android.view.inputmethod.InputMethodManager
import kotlin.math.abs
import kotlin.math.max

class KeyboardService : InputMethodService() {

    private val store by lazy { Store.get(this) }
    private lateinit var view: KeyboardView

    /** known=false یعنی مختصات لمس این حرف را نداریم (فقط خود اشتباه ثبت می‌شود) */
    private class Stroke(val label: String, val x: Float, val y: Float, val known: Boolean)
    private class Fix(val orig: String, val fixed: String, val t: Long)
    /** target: کلمه‌ای که الان در متن است؛ options: گزینه‌هایی که کاربر می‌تواند به‌جای آن بگذارد */
    private class Repl(val target: String, val options: List<String>, val revert: Boolean)

    private val recent = ArrayList<Stroke>()    // آخرین ضربه‌های تایپ‌شده
    private val deleted = ArrayList<Stroke>()   // پاک‌شده‌ها (به ترتیب اصلی تایپ)
    private val retyped = ArrayList<Stroke>()   // بازنویسی بعد از پاک کردن
    private var lastAct = 0L
    private var lastShift = 0L
    private var midEdit = false                 // اصلاح وسط متن (نه انتهای آن)
    private var privateField = false            // رمز عبور یا حالت ناشناس: چیزی یاد نمی‌گیرد
    private var lastFix: Fix? = null
    private var repl: Repl? = null
    private val noFix = HashSet<String>()       // کلمه‌هایی که کاربر خودش نخواسته عوض شوند

    override fun onCreateInputView(): View {
        view = KeyboardView(this, store)
        view.onKey = { d, nx, ny, x, y -> handleKey(d, nx, ny, x, y) }
        view.onSuggestion = { pickSuggestion(it) }
        view.onPicker = {
            (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker()
        }
        view.onSettings = {
            startActivity(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
        return view
    }

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        recent.clear(); deleted.clear(); retyped.clear()
        lastFix = null; repl = null
        view.reload()
        view.shift = 0
        val inType = info?.inputType ?: 0
        val variation = inType and InputType.TYPE_MASK_VARIATION
        privateField = when (inType and InputType.TYPE_MASK_CLASS) {
            InputType.TYPE_CLASS_TEXT ->
                variation == InputType.TYPE_TEXT_VARIATION_PASSWORD ||
                variation == InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD ||
                variation == InputType.TYPE_TEXT_VARIATION_WEB_PASSWORD
            InputType.TYPE_CLASS_NUMBER -> variation == InputType.TYPE_NUMBER_VARIATION_PASSWORD
            else -> false
        } || ((info?.imeOptions ?: 0) and EditorInfo.IME_FLAG_NO_PERSONALIZED_LEARNING) != 0
        val cls = inType and InputType.TYPE_MASK_CLASS
        view.layer = if (cls == InputType.TYPE_CLASS_NUMBER || cls == InputType.TYPE_CLASS_PHONE) 2 else 0
        refresh()
    }

    override fun onFinishInput() { super.onFinishInput(); store.save() }
    override fun onDestroy() { store.save(); super.onDestroy() }

    // ---------- کلیدها ----------
    private fun handleKey(k: KeyDef, nx: Float, ny: Float, x: Float, y: Float) {
        val ic = currentInputConnection ?: return
        if (k.kind == Kind.BACKSPACE && tryUndoFix(ic)) { repl = null; refresh(); return }
        if (k.kind != Kind.BACKSPACE) lastFix = null
        repl = null
        when (k.kind) {
            Kind.BACKSPACE -> {
                val sel = ic.getSelectedText(0)
                if (!sel.isNullOrEmpty()) {
                    ic.commitText("", 1); deleted.clear(); retyped.clear()
                } else {
                    val before = ic.getTextBeforeCursor(1, 0)?.toString() ?: ""
                    val mid = (ic.getTextAfterCursor(1, 0)?.length ?: 0) > 0
                    ic.deleteSurroundingText(1, 0)
                    if (retyped.isNotEmpty()) { deleted.clear(); retyped.clear() }
                    if (before.isNotEmpty()) {
                        deleted.add(0, takeStroke(before, mid))
                        midEdit = mid
                    }
                    lastAct = SystemClock.uptimeMillis()
                }
            }
            Kind.SPACE -> {
                autoFix(ic); ic.commitText(" ", 1)
                deleted.clear(); retyped.clear()
            }
            Kind.ENTER -> {
                autoFix(ic)
                val ei = currentInputEditorInfo
                val action = (ei?.imeOptions ?: 0) and EditorInfo.IME_MASK_ACTION
                val noAction = ((ei?.imeOptions ?: 0) and EditorInfo.IME_FLAG_NO_ENTER_ACTION) != 0
                if (ei == null || noAction || action == EditorInfo.IME_ACTION_NONE || action == EditorInfo.IME_ACTION_UNSPECIFIED)
                    ic.commitText("\n", 1)
                else ic.performEditorAction(action)
                deleted.clear(); retyped.clear()
            }
            Kind.SHIFT -> {
                val now = SystemClock.uptimeMillis()
                view.shift = when {
                    view.shift == 2 -> 0
                    view.shift == 1 && now - lastShift < 450 -> 2
                    view.shift == 1 -> 0
                    else -> 1
                }
                lastShift = now
            }
            Kind.LAYER -> view.layer = k.target
            Kind.CHAR -> typeChar(ic, k, nx, ny, x, y)
        }
        refresh()
    }

    /**
     * پیدا کردن ضربه‌ی مربوط به حرفی که پاک شد.
     * انتهای متن: فقط اگر آخرین ضربه همان حرف باشد.
     * وسط متن: فقط اگر در ۱۲۰ ضربه‌ی اخیر دقیقاً یک بار آمده باشد (تا اشتباه یاد نگیرد).
     */
    private fun takeStroke(c: String, mid: Boolean): Stroke {
        val lc = c.lowercase()
        if (!mid) {
            if (recent.isNotEmpty() && recent[recent.lastIndex].label == lc)
                return recent.removeAt(recent.lastIndex)
        } else {
            val from = max(0, recent.size - 120)
            val hits = (from until recent.size).filter { recent[it].label == lc }
            if (hits.size == 1) return recent.removeAt(hits[0])
        }
        return Stroke(lc, 0f, 0f, false)
    }

    private fun typeChar(ic: InputConnection, k: KeyDef, nx: Float, ny: Float, x: Float, y: Float) {
        val o = if (view.layer == 1 && view.shift > 0) k.out.uppercase() else k.out
        val mark = Character.getType(o[0]) == Character.NON_SPACING_MARK.toInt()
        if (!(o[0].isLetter() || o == "\u200c" || mark)) endWord(ic)
        ic.commitText(o, 1)
        if (view.shift == 1) view.shift = 0
        if (!k.learn) return

        val now = SystemClock.uptimeMillis()
        store.strokeCommitted(k.label)
        val s = Stroke(k.label, x, y, true)

        // اصلاح انتهای متن: ۶ ثانیه؛ اصلاح وسط متن: ۳۰ ثانیه
        val window = if (midEdit) 30000L else 6000L
        if (deleted.isNotEmpty() && now - lastAct < window) {
            retyped.add(s)
            lastAct = now
            if (retyped.size >= deleted.size) { evaluate(); deleted.clear(); retyped.clear() }
        } else { deleted.clear(); retyped.clear() }

        recent.add(s)
        if (recent.size > 300) recent.removeAt(0)
        if (store.adaptive) store.learnSample(k.label, nx, ny, 0.01f)
    }

    /** «حذف و بازنویسی» را مقایسه می‌کند و از اشتباه‌ها یاد می‌گیرد */
    private fun evaluate() {
        val n = deleted.size
        if (n > 4) return
        val pairs = ArrayList<Pair<Stroke, Stroke>>()
        for (i in 0 until n) if (deleted[i].label != retyped[i].label) pairs.add(deleted[i] to retyped[i])
        if (pairs.isEmpty() || pairs.size > (n + 1) / 2) return
        for ((old, new) in pairs) {
            val want = view.cellOf(new.label) ?: continue
            val hit = view.cellOf(old.label) ?: continue
            // فقط اگر همسایه‌ی فیزیکی باشند، اشتباه لمسی حساب می‌شود
            if (abs(want.cx - hit.cx) / want.w > 1.7f || abs(want.cy - hit.cy) / want.h > 1.2f) continue
            if (old.known) {
                val nx = (old.x - want.cx) / want.w
                val ny = (old.y - want.cy) / want.h
                if (abs(nx) <= 1.3f && abs(ny) <= 1.1f && store.adaptive) store.learnSample(new.label, nx, ny, 0.12f)
            }
            store.recordError(new.label, old.label)
        }
        view.rebuild()
    }

    // ---------- کلمه، بافت جمله و تصحیح ----------
    private fun isWordChar(ch: Char) =
        ch.isLetter() || ch == '\u200c' || Character.getType(ch) == Character.NON_SPACING_MARK.toInt()

    private fun endsWithWord(ic: InputConnection): Boolean {
        val c = ic.getTextBeforeCursor(1, 0)?.toString()
        return !c.isNullOrEmpty() && isWordChar(c[0])
    }

    private fun trailingWord(ic: InputConnection): String {
        val t = ic.getTextBeforeCursor(24, 0)?.toString() ?: ""
        var i = t.length
        while (i > 0 && isWordChar(t[i - 1])) i--
        return t.substring(i)
    }

    /** آخرین n کلمه‌ی قبل از مکان‌نما */
    private fun wordsBefore(ic: InputConnection, n: Int): MutableList<String> {
        val t = ic.getTextBeforeCursor(120, 0)?.toString() ?: return ArrayList()
        val out = ArrayList<String>()
        val sb = StringBuilder()
        for (ch in t) {
            if (isWordChar(ch)) sb.append(ch)
            else if (sb.isNotEmpty()) { out.add(sb.toString()); sb.setLength(0) }
        }
        if (sb.isNotEmpty()) out.add(sb.toString())
        return if (out.size > n) ArrayList(out.subList(out.size - n, out.size)) else out
    }

    private fun endWord(ic: InputConnection) {
        if (privateField || !endsWithWord(ic)) return
        val ws = wordsBefore(ic, 2)
        if (ws.isEmpty()) return
        store.learnWord(ws.last())
        store.learnBigram(ws.getOrNull(ws.size - 2), ws.last())
    }

    /** کلمه‌ی old را (نزدیک‌ترین نمونه به مکان‌نما) با new عوض می‌کند، حتی اگر چند کلمه عقب‌تر باشد */
    private fun replaceWordBack(ic: InputConnection, old: String, new: String): Boolean {
        val t = ic.getTextBeforeCursor(120, 0)?.toString() ?: return false
        var idx = t.lastIndexOf(old)
        while (idx >= 0) {
            val beforeOk = idx == 0 || !isWordChar(t[idx - 1])
            val e = idx + old.length
            val afterOk = e >= t.length || !isWordChar(t[e])
            if (beforeOk && afterOk) break
            idx = if (idx == 0) -1 else t.lastIndexOf(old, idx - 1)
        }
        if (idx < 0) return false
        val tail = t.substring(idx)
        ic.deleteSurroundingText(tail.length, 0)
        ic.commitText(new + tail.substring(old.length), 1)
        return true
    }

    /**
     * هنگام فاصله/اینتر: چهار کلمه‌ی آخر را با توجه به کلمه‌های دو طرفشان می‌سنجد.
     * اگر بافت قاطع باشد، خودکار درست می‌کند؛ اگر مبهم باشد، گزینه‌ها را در نوار پیشنهاد می‌گذارد.
     */
    private fun autoFix(ic: InputConnection) {
        if (privateField || !endsWithWord(ic)) return
        val ws = wordsBefore(ic, 5)
        if (ws.isEmpty()) return
        if (store.autoCorrect) {
            var offer: Repl? = null
            var fixedAny: Repl? = null
            val lowest = max(0, ws.size - 4)
            var i = ws.size - 1
            while (i >= lowest) {
                val w = ws[i]
                if (w !in noFix) {
                    val window = ws.filterIndexed { j, _ -> j != i }
                    val d = WordBrain.decide(store, w, ws.getOrNull(i - 1), ws.getOrNull(i + 1), window)
                    val s = d.single
                    if (s != null) {
                        if (replaceWordBack(ic, w, s)) {
                            if (i == ws.size - 1) lastFix = Fix(w, s, SystemClock.uptimeMillis())
                            ws[i] = s
                            fixedAny = Repl(s, listOf(w), true)
                        }
                    } else if (i == ws.size - 1 && d.options.size > 1 && fixedAny == null) {
                        offer = Repl(w, d.options, false)
                    }
                }
                i--
            }
            repl = fixedAny ?: offer
        }
        val last = ws.last()
        store.learnWord(last)
        store.learnBigram(ws.getOrNull(ws.size - 2), last)
    }

    /** پاک‌کردنِ بلافاصله بعد از تصحیح خودکار، کلمه‌ی اصلی را برمی‌گرداند */
    private fun tryUndoFix(ic: InputConnection): Boolean {
        val lf = lastFix ?: return false
        lastFix = null
        if (SystemClock.uptimeMillis() - lf.t > 5000) return false
        val before = ic.getTextBeforeCursor(lf.fixed.length + 1, 0)?.toString() ?: return false
        if (before != lf.fixed + " ") return false
        ic.deleteSurroundingText(lf.fixed.length + 1, 0)
        ic.commitText(lf.orig, 1)
        store.boost(lf.orig)
        noFix.add(lf.orig)
        deleted.clear(); retyped.clear()
        return true
    }

    private fun pickSuggestion(w: String) {
        val ic = currentInputConnection ?: return
        val r = repl
        if (r != null && !endsWithWord(ic)) {
            if (replaceWordBack(ic, r.target, w)) {
                if (r.revert) { store.boost(w); noFix.add(w) }
                else if (w == r.target) noFix.add(w)
                else store.learnWord(w)
            }
            repl = null; lastFix = null
            recent.clear(); deleted.clear(); retyped.clear()
            refresh()
            return
        }
        val cur = trailingWord(ic)
        ic.deleteSurroundingText(cur.length, 0)
        ic.commitText("$w ", 1)
        if (!privateField) store.learnWord(w)
        recent.clear(); deleted.clear(); retyped.clear()
        refresh()
    }

    private fun refresh() {
        val ic = currentInputConnection
        val cur = if (ic != null && !privateField) trailingWord(ic) else ""
        view.currentWord = cur
        val r = repl
        view.suggestions = when {
            r != null && cur.isEmpty() -> r.options
            store.suggest && cur.isNotEmpty() -> store.suggestions(cur)
            else -> emptyList()
        }
        view.invalidate()
    }
}
