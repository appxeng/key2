package com.adaptivekb

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.SystemClock
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView

class MainActivity : Activity() {

    private lateinit var st: Store
    private val BG = 0xFF0F1117.toInt()
    private val CARD = 0xFF1A1D26.toInt()
    private val MUTED = 0xFF8D93A5.toInt()
    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT
    private val accent get() = Palette.accents[st.accent.coerceIn(0, Palette.accents.size - 1)]
    private var sentence = 0
    private var scrollY = 0
    private var taps = 0
    private var lastTap = 0L
    private lateinit var scroll: ScrollView

    private val sentencesFa = listOf(
        "مکانیک ماشین را درست کرد",
        "راهبه در صومعه زندگی می‌کند",
        "امروز هوا خیلی خوب است",
        "گربه‌ی کوچک روی دیوار نشسته بود",
        "کتاب خوب بهترین همراه سفر است",
        "تهران شهر شلوغ و پرجنب‌وجوش است"
    )
    private val sentencesEn = listOf(
        "The mechanic fixed the car",
        "A quick brown fox jumps over the lazy dog",
        "The weather is really nice today",
        "A good book is the best travel companion",
        "Please send me the report tomorrow morning"
    )

    private fun t(fa: String, en: String) = if (st.isFa) fa else en
    private fun num(s: String) =
        if (st.isFa) s.map { if (it in '0'..'9') '\u06F0' + (it - '0') else it }.joinToString("") else s

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        st = Store.get(this)
        window.statusBarColor = BG
        window.navigationBarColor = BG
    }

    override fun onResume() { super.onResume(); build() }
    override fun onPause() { super.onPause(); st.save() }

    private fun px(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun round(color: Int, r: Float = 16f) =
        GradientDrawable().apply { setColor(color); cornerRadius = r * resources.displayMetrics.density }

    private fun tv(text: String, size: Float, color: Int = Color.WHITE, bold: Boolean = false) =
        TextView(this).apply {
            this.text = text; textSize = size; setTextColor(color); gravity = Gravity.START
            if (bold) typeface = Typeface.DEFAULT_BOLD
        }

    private fun card(title: String, sub: String? = null): LinearLayout {
        val c = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = round(CARD, 20f)
            setPadding(px(18), px(16), px(18), px(18))
            layoutParams = LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = px(14) }
        }
        c.addView(tv(title, 17f, Color.WHITE, true))
        if (sub != null) c.addView(tv(sub, 13f, MUTED).apply { setPadding(0, px(4), 0, px(6)) })
        return c
    }

    private fun pill(text: String, filled: Boolean = true, onClick: () -> Unit) = Button(this).apply {
        this.text = text; setTextColor(Color.WHITE); isAllCaps = false; textSize = 15f
        background = round(if (filled) accent else 0xFF2A2E3A.toInt(), 14f)
        setOnClickListener { onClick() }
        layoutParams = LinearLayout.LayoutParams(MATCH, px(48)).apply { topMargin = px(8) }
    }

    private fun chip(text: String, selected: Boolean, onClick: () -> Unit) = Button(this).apply {
        this.text = text; isAllCaps = false; setTextColor(Color.WHITE)
        background = round(if (selected) accent else 0xFF2A2E3A.toInt(), 12f)
        layoutParams = LinearLayout.LayoutParams(0, px(42), 1f).apply { marginEnd = px(8) }
        setOnClickListener { onClick() }
    }

    private fun switchRow(title: String, sub: String, on: Boolean, change: (Boolean) -> Unit): View {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(0, px(8), 0, px(8))
        }
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, WRAP, 1f)
        }
        col.addView(tv(title, 15f))
        col.addView(tv(sub, 12f, MUTED))
        val sw = Switch(this).apply { isChecked = on; setOnCheckedChangeListener { _, v -> change(v) } }
        row.addView(col); row.addView(sw)
        return row
    }

    private fun footerTap() {
        val now = SystemClock.uptimeMillis()
        taps = if (now - lastTap < 1200) taps + 1 else 1
        lastTap = now
        if (taps >= 5) {
            taps = 0
            startActivity(Intent(this, SpiralActivity::class.java))
        }
    }

    private fun build() {
        if (::scroll.isInitialized) scrollY = scroll.scrollY
        scroll = ScrollView(this).apply {
            setBackgroundColor(BG)
            layoutDirection = if (st.isFa) View.LAYOUT_DIRECTION_RTL else View.LAYOUT_DIRECTION_LTR
        }
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(px(16), px(28), px(16), px(24))
        }
        scroll.addView(col)

        col.addView(tv("AI Keyboard", 26f, Color.WHITE, true))
        col.addView(tv(t("هر چه بیشتر تایپ کنی، دقیق‌تر و شخصی‌تر می‌شود",
            "The more you type, the more accurate and personal it gets"), 14f, MUTED)
            .apply { setPadding(0, px(4), 0, 0) })

        // ----- زبان / Language -----
        val lang = card("زبان / Language")
        val langRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        langRow.addView(chip("فارسی", st.isFa) { st.lang = 0; build() })
        langRow.addView(chip("English", !st.isFa) { st.lang = 1; build() })
        lang.addView(langRow)
        col.addView(lang)

        // ----- راه‌اندازی -----
        val setup = card(t("راه‌اندازی", "Setup"),
            t("اول کیبورد را فعال کن، بعد آن را انتخاب کن", "First enable the keyboard, then select it"))
        setup.addView(pill(t("۱. فعال‌سازی کیبورد", "1. Enable keyboard")) {
            startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS))
        })
        setup.addView(pill(t("۲. انتخاب کیبورد", "2. Choose keyboard"), false) {
            (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker()
        })
        col.addView(setup)

        // ----- تمرین -----
        val list = if (st.isFa) sentencesFa else sentencesEn
        sentence %= list.size
        val train = card(t("تمرین سریع", "Quick practice"),
            t("جمله را بنویس تا کیبورد زودتر با انگشت‌هایت آشنا شود",
                "Type the sentence so the keyboard learns your fingers faster"))
        val target = tv(list[sentence], 18f, accent, true).apply { setPadding(0, px(6), 0, px(10)) }
        val field = EditText(this).apply {
            hint = t("اینجا تایپ کن…", "Type here…"); setHintTextColor(MUTED); setTextColor(Color.WHITE)
            background = round(0xFF11131A.toInt(), 14f); setPadding(px(14), px(12), px(14), px(12))
            gravity = Gravity.START
        }
        train.addView(target); train.addView(field)
        train.addView(pill(t("جمله‌ی بعدی", "Next sentence"), false) {
            sentence = (sentence + 1) % list.size; target.text = list[sentence]; field.setText("")
        })
        col.addView(train)

        // ----- آمار -----
        val days = st.last7()
        val stats = card(t("پیشرفت دقت تایپ", "Typing accuracy progress"),
            t("درصد ضربه‌هایی که نیاز به اصلاح نداشتند (۷ روز اخیر)",
                "Share of keystrokes that needed no correction (last 7 days)"))
        stats.addView(BarsView(this, days, accent, st.isFa).apply { layoutParams = LinearLayout.LayoutParams(MATCH, px(140)) })
        val totalErr = st.keys.values.sumOf { it.errors }
        stats.addView(tv(t("اصلاح‌های یادگرفته‌شده: ${num(totalErr.toString())}   |   کلمه‌های حفظ‌شده: ${num(st.words.size.toString())}",
            "Learned corrections: $totalErr   |   Remembered words: ${st.words.size}"), 13f, MUTED)
            .apply { setPadding(0, px(8), 0, px(6)) })
        val top = st.confusion.entries.sortedByDescending { it.value }.take(5)
        if (top.isEmpty()) {
            stats.addView(tv(t("هنوز اشتباهی ثبت نشده. تایپ کن و اشتباه‌هایت را پاک کن و درست بنویس!",
                "No mistakes recorded yet. Type, delete a wrong letter and retype it!"), 13f, MUTED))
        } else {
            stats.addView(tv(t("بیشترین اشتباه‌ها", "Most common mistakes"), 14f, Color.WHITE, true)
                .apply { setPadding(0, px(6), 0, px(4)) })
            for (e in top) {
                val p = e.key.split(">")
                stats.addView(tv(
                    t("می‌خواستی «${p[0]}» بزنی، «${p[1]}» خورد  ←  ${num(e.value.toString())} بار",
                        "You meant «${p[0]}» but hit «${p[1]}»  →  ${e.value}×"), 13f, 0xFFC9CEDB.toInt()))
            }
        }
        col.addView(stats)

        // ----- ظاهر -----
        val look = card(t("ظاهر و حس کیبورد", "Look & feel"))
        look.addView(tv(t("رنگ اصلی", "Accent color"), 13f, MUTED).apply { setPadding(0, px(6), 0, px(6)) })
        val dots = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        Palette.accents.forEachIndexed { i, c ->
            val dot = View(this).apply {
                background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL; setColor(c)
                    if (i == st.accent) setStroke(px(3), Color.WHITE)
                }
                layoutParams = LinearLayout.LayoutParams(px(38), px(38)).apply { marginEnd = px(10) }
                setOnClickListener { st.accent = i; build() }
            }
            dots.addView(dot)
        }
        look.addView(dots)
        look.addView(tv(t("تم", "Theme"), 13f, MUTED).apply { setPadding(0, px(14), 0, px(2)) })
        val themes = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf(t("تیره", "Dark"), t("روشن", "Light"), t("آمولد", "AMOLED")).forEachIndexed { i, n ->
            themes.addView(chip(n, st.theme == i) { st.theme = i; build() })
        }
        look.addView(themes)
        look.addView(tv(t("ارتفاع کلیدها: ${num(st.keyDp.toString())}", "Key height: ${st.keyDp}"), 13f, MUTED)
            .apply { setPadding(0, px(14), 0, 0) })
        look.addView(SeekBar(this).apply {
            max = 32; progress = st.keyDp - 40
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) { st.keyDp = 40 + p }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) { build() }
            })
        })
        look.addView(switchRow(t("ردیف اعداد", "Number row"), t("مثل کیبورد گوگل: پیش‌فرض خاموش", "Off by default, like Gboard"), st.numRow) { st.numRow = it })
        look.addView(switchRow(t("نمایش پیش‌نمایش حرف", "Letter preview"), t("حباب بالای کلید", "Bubble above the key"), st.preview) { st.preview = it })
        look.addView(switchRow(t("لرزش هنگام تایپ", "Haptic feedback"), t("بازخورد لمسی", "Vibrate on keypress"), st.haptic) { st.haptic = it })
        look.addView(switchRow(t("نوار پیشنهاد کلمه", "Word suggestions"), t("از کلمه‌هایی که خودت می‌نویسی", "From words you type"), st.suggest) { st.suggest = it })
        col.addView(look)

        // ----- یادگیری -----
        val ai = card(t("یادگیری", "Learning"), t("همه‌ی داده‌ها فقط روی همین گوشی می‌مانند", "All data stays on this phone"))
        ai.addView(switchRow(t("جابجایی نامرئی ناحیه‌ی لمس", "Invisible touch-zone shift"),
            t("ظاهر ثابت، دقت بیشتر (پیشنهادی)", "Fixed look, better accuracy (recommended)"), st.adaptive) { st.adaptive = it })
        ai.addView(switchRow(t("بزرگ‌شدن ظاهری کلیدهای پراشتباه", "Visible growth of mistaken keys"),
            t("اندازه‌ی کلید؛ بعد از ثابت‌شدن تغییر نمی‌کند", "Key size; stops changing once frozen"), st.grow) { st.grow = it })
        ai.addView(tv(t("شدت بزرگ‌شدن: ${num(st.growPct.toString())}٪", "Growth strength: ${st.growPct}%"), 13f, MUTED).apply { setPadding(0, px(8), 0, 0) })
        ai.addView(SeekBar(this).apply {
            max = 150; progress = st.growPct - 50
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) { st.growPct = 50 + p }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) { build() }
            })
        })
        ai.addView(switchRow(t("نمای حرارتی", "Heat map"),
            t("نشان‌دادن کلیدهای پراشتباه و مرکز لمس تو", "Show error-prone keys and your touch centers"), st.heat) { st.heat = it })
        ai.addView(switchRow(t("تصحیح خودکار", "Auto-correct"), t("غلط‌های تایپی را با توجه به جمله درست می‌کند؛ اگر مطمئن نباشد چند گزینه می‌دهد. پاک‌کردنِ فوری، برمی‌گرداند", "Fixes typos using the sentence; offers choices when unsure. Backspace right after undoes it"), st.autoCorrect) { st.autoCorrect = it })
        ai.addView(pill(t("پاک‌کردن همه‌ی یادگیری", "Erase all learning"), false) { st.resetLearning(); build() })
        col.addView(ai)

        // ----- کلید زنده -----
        val live = card(t("کلید زنده", "Live keys"),
            t("اول اندازه‌ی کلیدها طبق اشتباه‌هایت عوض می‌شود. بعد از تعداد ضربه‌ی مشخص، اندازه‌ها همان‌طور که هستند ثابت می‌مانند و کلید زنده نامرئی کار می‌کند",
                "At first key sizes follow your mistakes. After enough typing the sizes stay as they are and the live key keeps working invisibly"))
        live.addView(switchRow(t("ثابت‌شدن اندازه‌ها بعد از تعداد ضربه", "Freeze sizes after the keystroke count"),
            t("اندازه‌ها برنمی‌گردند؛ همان‌جا می‌مانند", "Sizes do not reset; they stay where they are"), st.liveAuto) { st.liveAuto = it; build() })
        live.addView(tv(t("بعد از ${num(st.liveAfter.toString())} ضربه (الان: ${num(st.totalHits.toString())})",
            "After ${st.liveAfter} keystrokes (now: ${st.totalHits})"), 13f, MUTED).apply { setPadding(0, px(8), 0, 0) })
        live.addView(SeekBar(this).apply {
            max = 29; progress = (st.liveAfter / 100 - 1).coerceIn(0, 29)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) { st.liveAfter = (p + 1) * 100 }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) { build() }
            })
        })
        live.addView(switchRow(t("نمایش شکل کلید زنده", "Show live key shape"),
            t("کلید زنده همیشه نامرئی کار می‌کند؛ با روشن‌کردن این گزینه، شکل واقعی و غیرهندسی‌اش دیده می‌شود",
                "The live key always works invisibly; turn this on to see its real, organic shape"), st.liveShow) { st.liveShow = it; build() })
        live.addView(KeyboardView(this, st).apply {
            demo = true
            layoutParams = LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = px(10) }
        })
        col.addView(live)

        // ----- امضا (۵ بار لمس = صفحه‌ی مخفی) -----
        col.addView(tv("by hasan.d", 11f, 0xFF5A6074.toInt()).apply {
            gravity = Gravity.CENTER
            setPadding(0, px(30), 0, px(30))
            setOnClickListener { footerTap() }
            layoutParams = LinearLayout.LayoutParams(MATCH, WRAP)
        })

        setContentView(scroll)
        scroll.post { scroll.scrollTo(0, scrollY) }
    }

    /** نمودار میله‌ای ساده‌ی دقت */
    class BarsView(
        ctx: Context, private val data: List<Triple<Int, Int, Int>>,
        private val color: Int, private val isFa: Boolean
    ) : View(ctx) {
        private val p = Paint(Paint.ANTI_ALIAS_FLAG)
        private fun num(s: String) =
            if (isFa) s.map { if (it in '0'..'9') '\u06F0' + (it - '0') else it }.joinToString("") else s

        override fun onDraw(c: Canvas) {
            val d = resources.displayMetrics.density
            val n = data.size
            val slot = width / n.toFloat()
            val chartH = height - 34 * d
            p.textAlign = Paint.Align.CENTER
            for (i in 0 until n) {
                val idx = if (isFa) n - 1 - i else i       // فارسی: قدیمی‌ترین سمت راست
                val (s, e, day) = data[idx]
                val cx = slot * (i + 0.5f)
                val bw = slot * 0.46f
                p.color = 0xFF262A36.toInt()
                c.drawRoundRect(RectF(cx - bw / 2, 16 * d, cx + bw / 2, 16 * d + chartH), 8 * d, 8 * d, p)
                if (s > 0) {
                    val acc = (1f - e.toFloat() / s).coerceIn(0f, 1f)
                    val frac = ((acc - 0.5f) / 0.5f).coerceIn(0.04f, 1f)
                    p.color = color
                    c.drawRoundRect(RectF(cx - bw / 2, 16 * d + chartH * (1 - frac), cx + bw / 2, 16 * d + chartH), 8 * d, 8 * d, p)
                    p.color = Color.WHITE; p.textSize = 10 * d
                    c.drawText(num("${(acc * 100).toInt()}"), cx, 12 * d, p)
                }
                p.color = 0xFF8D93A5.toInt(); p.textSize = 11 * d
                c.drawText(num(day.toString()), cx, height - 6 * d, p)
            }
        }
    }
}
