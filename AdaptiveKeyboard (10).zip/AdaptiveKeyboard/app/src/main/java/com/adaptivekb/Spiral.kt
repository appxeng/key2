package com.adaptivekb

import android.app.Activity
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.os.Bundle
import android.os.SystemClock
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/** صفحه‌ی مخفی: کیبورد مارپیچی که مثل پره‌ی هلیکوپتر می‌چرخد */
class SpiralActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.statusBarColor = Color.BLACK
        window.navigationBarColor = Color.BLACK
        setContentView(SpiralView(this))
    }
}

class SpiralView(ctx: Context) : View(ctx) {
    private val d = resources.displayMetrics.density
    private val rings = listOf("QWERTYUIOP", "ASDFGHJKL", "ZXCVBNM")
    private val speeds = floatArrayOf(0.5f, -0.75f, 1.0f)       // جهت و سرعت هر حلقه
    private val radiusF = floatArrayOf(0.40f, 0.285f, 0.17f)
    private val rot = FloatArray(3)

    private class K(val ch: Char, var x: Float, var y: Float, var s: Float)
    private val ks = ArrayList<K>()
    private val flashes = HashMap<Char, Float>()
    private val typed = StringBuilder()

    private var lastT = 0L
    private var slow = 1f
    private var down = false
    private var cx = 0f; private var cy = 0f; private var m = 0f
    private var bg: Shader? = null
    private val oval = RectF()
    private val keyRect = RectF()
    private val spRect = RectF()
    private val acc = Palette.accents[Store.get(ctx).accent.coerceIn(0, Palette.accents.size - 1)]

    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val tp = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER; typeface = Typeface.DEFAULT_BOLD
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        cx = w / 2f
        cy = h / 2f
        m = min(w.toFloat(), h * 0.86f)
        bg = RadialGradient(
            cx, cy, max(w, h) * 0.75f,
            intArrayOf(0xFF111C5C.toInt(), 0xFF060A1C.toInt(), 0xFF000000.toInt()),
            floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP
        )
        spRect.set(w * 0.28f, h - 88 * d, w * 0.72f, h - 38 * d)
    }

    private fun mix(a: Int, b: Int, t: Float): Int {
        val u = t.coerceIn(0f, 1f)
        return Color.rgb(
            (Color.red(a) + (Color.red(b) - Color.red(a)) * u).toInt(),
            (Color.green(a) + (Color.green(b) - Color.green(a)) * u).toInt(),
            (Color.blue(a) + (Color.blue(b) - Color.blue(a)) * u).toInt()
        )
    }

    override fun onDraw(c: Canvas) {
        val now = SystemClock.uptimeMillis()
        val dt = if (lastT == 0L) 0.016f else ((now - lastT) / 1000f).coerceAtMost(0.05f)
        lastT = now
        slow += ((if (down) 0.1f else 1f) - slow) * min(1f, dt * 5f)   // با لمس، آهسته می‌شود
        val t = now / 1000f

        p.style = Paint.Style.FILL
        p.shader = bg
        c.drawRect(0f, 0f, width.toFloat(), height.toFloat(), p)
        p.shader = null

        ks.clear()
        val two = (2 * PI).toFloat()
        for (i in 0..2) {
            rot[i] += speeds[i] * slow * dt
            val r = radiusF[i] * m
            val n = rings[i].length

            // سیم حلقه
            p.style = Paint.Style.STROKE
            p.strokeWidth = 3 * d
            p.color = Color.argb(70, Color.red(acc), Color.green(acc), Color.blue(acc))
            c.drawCircle(cx, cy, r, p)
            // قطعه‌ی نورانی که دور حلقه می‌چرخد
            oval.set(cx - r, cy - r, cx + r, cy + r)
            val deg = Math.toDegrees(rot[i].toDouble()).toFloat()
            for (g in 0..2) {
                p.strokeWidth = (11 - g * 3) * d
                p.color = Color.argb(45 + g * 55, 150, 110, 255)
                c.drawArc(oval, deg - 45f, 90f - g * 25f, false, p)
            }

            // کلیدها
            val s = min(two * r / n * 0.8f, m * 0.1f)
            for (k in 0 until n) {
                val a = rot[i] + k * two / n
                val bob = sin(t * 2.6f + k * 0.9f + i * 1.7f) * 8 * d       // بالا و پایین
                val x = cx + r * cos(a)
                val y = cy + r * sin(a) + bob
                val ch = rings[i][k]
                ks.add(K(ch, x, y, s))

                // هر بار از دروازه‌ی بالا رد می‌شود، می‌درخشد
                var diff = ((a + PI / 2) % (2 * PI)).toFloat()
                if (diff > PI) diff -= two
                val gate = max(0f, 1f - abs(diff) / 0.28f)
                val f = flashes[ch] ?: 0f
                if (f > 0f) flashes[ch] = max(0f, f - dt * 2.5f)

                val glow = max(gate, f)
                val sc = 1f + 0.12f * glow
                keyRect.set(x - s * sc / 2, y - s * 1.1f * sc / 2, x + s * sc / 2, y + s * 1.1f * sc / 2)
                p.style = Paint.Style.FILL
                p.color = mix(0xFF16205A.toInt(), acc, glow)
                c.drawRoundRect(keyRect, s * 0.28f, s * 0.28f, p)
                p.style = Paint.Style.STROKE
                p.strokeWidth = 1.5f * d
                p.color = mix(0xFF4A5CC8.toInt(), Color.WHITE, glow)
                c.drawRoundRect(keyRect, s * 0.28f, s * 0.28f, p)
                tp.color = Color.WHITE
                tp.textSize = s * 0.5f
                c.drawText(ch.toString(), x, y - (tp.ascent() + tp.descent()) / 2f, tp)
            }
        }

        // دروازه‌ای که کلیدها از آن رد می‌شوند
        p.style = Paint.Style.STROKE
        p.strokeWidth = 2 * d
        p.color = Color.argb(110, 255, 255, 255)
        c.drawLine(cx, cy - radiusF[0] * m - 30 * d, cx, cy - radiusF[2] * m + 24 * d, p)

        // مرکز
        val pulse = 1f + 0.05f * sin(t * 3f)
        val cr = 0.085f * m * pulse
        p.style = Paint.Style.FILL
        p.color = 0xFF0A1040.toInt()
        c.drawCircle(cx, cy, cr, p)
        p.style = Paint.Style.STROKE
        p.strokeWidth = 3 * d
        p.color = acc
        c.drawCircle(cx, cy, cr, p)
        tp.color = Color.WHITE
        tp.textSize = cr * 0.9f
        c.drawText("AI", cx, cy - (tp.ascent() + tp.descent()) / 2f, tp)

        // پاک‌کن و فاصله
        val bx = width - 46 * d
        val by = 70 * d
        p.style = Paint.Style.FILL
        p.color = 0xFF16205A.toInt()
        c.drawCircle(bx, by, 30 * d, p)
        p.style = Paint.Style.STROKE
        p.strokeWidth = 2 * d
        p.color = acc
        c.drawCircle(bx, by, 30 * d, p)
        tp.textSize = 22 * d
        c.drawText("⌫", bx, by - (tp.ascent() + tp.descent()) / 2f, tp)

        p.style = Paint.Style.FILL
        p.color = 0xFF16205A.toInt()
        c.drawRoundRect(spRect, 24 * d, 24 * d, p)
        p.style = Paint.Style.STROKE
        p.color = acc
        c.drawRoundRect(spRect, 24 * d, 24 * d, p)

        // متن تایپ‌شده
        tp.textSize = 24 * d
        val shown = if (typed.length > 18) typed.substring(typed.length - 18) else typed.toString()
        c.drawText(shown, width / 2f - 20 * d, 76 * d, tp)

        tp.textSize = 11 * d
        tp.color = Color.argb(140, 255, 255, 255)
        c.drawText("by hasan.d", width / 2f, height - 14 * d, tp)

        postInvalidateOnAnimation()
    }

    private fun buzz() { performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP) }

    private fun hit(x: Float, y: Float) {
        if (hypot(x - (width - 46 * d), y - 70 * d) < 34 * d) {
            if (typed.isNotEmpty()) typed.deleteCharAt(typed.length - 1)
            buzz(); return
        }
        if (spRect.contains(x, y)) { typed.append(' '); buzz(); return }
        var best: K? = null
        var bd = Float.MAX_VALUE
        for (k in ks) {
            val dd = hypot(x - k.x, y - k.y)
            if (dd < bd) { bd = dd; best = k }
        }
        val b = best ?: return
        if (bd < b.s * 0.8f) {
            if (typed.length < 200) typed.append(b.ch)
            flashes[b.ch] = 1f
            buzz()
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> { down = true; hit(e.x, e.y) }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> down = false
        }
        return true
    }
}
