package com.adaptivekb

import android.inputmethodservice.InputMethodService
import android.os.SystemClock
import android.text.InputType
import android.view.View
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputConnection
import kotlin.math.abs
import kotlin.math.max

class KeyboardService : InputMethodService() {

    private val store by lazy { Store.get(this) }
    private lateinit var view: KeyboardView

    /** known=false یعنی مختصات لمس این حرف را نداریم (فقط خود اشتباه ثبت می‌شود) */
    private class Stroke(val label: String, val x: Float, val y: Float, val known: Boolean)

    private val recent = ArrayList<Stroke>()    // آخرین ضربه‌های تایپ‌شده
    private val deleted = ArrayList<Stroke>()   // پاک‌شده‌ها (به ترتیب اصلی تایپ)
    private val retyped = ArrayList<Stroke>()   // بازنویسی بعد از پاک کردن
    private var lastAct = 0L
    private var lastShift = 0L
    private var midEdit = false                 // اصلاح وسط متن (نه انتهای آن)
    private var privateField = false            // رمز عبور یا حالت ناشناس: کلمه یاد نمی‌گیرد

    override fun onCreateInputView(): View {
        view = KeyboardView(this, store)
        view.onKey = { d, nx, ny, x, y -> handleKey(d, nx, ny, x, y) }
        view.onSuggestion = { pickSuggestion(it) }
        return view
    }

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        recent.clear(); deleted.clear(); retyped.clear()
        view.reload()
        view.shift = 0
        val inType = info?.inputType ?: 0
        val variation = inType and InputType.TYPE_MASK_VARIATION
        privateField = when (inType and InputType.TYPE_MASK_CLASS) {
            InputType.TYPE_CLASS_TEXT ->
                variation == InputType.TYPE_TEXT_VARIATION_PASSWORD ||
                variation == InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD ||
                variation == InputType.TYPE_TEXT_VARIATION_WEB_PASSWORD
            InputType.TYPE_CLASS_NUMBER -> variation == InputType.TYPE_NUMBER_VARIATION_PASSWORD
            else -> false
        } || ((info?.imeOptions ?: 0) and EditorInfo.IME_FLAG_NO_PERSONALIZED_LEARNING) != 0
        val cls = inType and InputType.TYPE_MASK_CLASS
        view.layer = if (cls == InputType.TYPE_CLASS_NUMBER || cls == InputType.TYPE_CLASS_PHONE) 2 else 0
        refresh()
    }

    override fun onFinishInput() { super.onFinishInput(); store.save() }
    override fun onDestroy() { store.save(); super.onDestroy() }

    // ---------- کلیدها ----------
    private fun handleKey(k: KeyDef, nx: Float, ny: Float, x: Float, y: Float) {
        val ic = currentInputConnection ?: return
        when (k.kind) {
            Kind.BACKSPACE -> {
                val sel = ic.getSelectedText(0)
                if (!sel.isNullOrEmpty()) {
                    ic.commitText("", 1); deleted.clear(); retyped.clear()
                } else {
                    val before = ic.getTextBeforeCursor(1, 0)?.toString() ?: ""
                    val mid = (ic.getTextAfterCursor(1, 0)?.length ?: 0) > 0
                    ic.deleteSurroundingText(1, 0)
                    if (retyped.isNotEmpty()) { deleted.clear(); retyped.clear() }
                    if (before.isNotEmpty()) {
                        deleted.add(0, takeStroke(before, mid))
                        midEdit = mid
                    }
                    lastAct = SystemClock.uptimeMillis()
                }
            }
            Kind.SPACE -> {
                endWord(ic); ic.commitText(" ", 1)
                deleted.clear(); retyped.clear()
            }
            Kind.ENTER -> {
                endWord(ic)
                val ei = currentInputEditorInfo
                val action = (ei?.imeOptions ?: 0) and EditorInfo.IME_MASK_ACTION
                val noAction = ((ei?.imeOptions ?: 0) and EditorInfo.IME_FLAG_NO_ENTER_ACTION) != 0
                if (ei == null || noAction || action == EditorInfo.IME_ACTION_NONE || action == EditorInfo.IME_ACTION_UNSPECIFIED)
                    ic.commitText("\n", 1)
                else ic.performEditorAction(action)
                deleted.clear(); retyped.clear()
            }
            Kind.SHIFT -> {
                val now = SystemClock.uptimeMillis()
                view.shift = when {
                    view.shift == 2 -> 0
                    view.shift == 1 && now - lastShift < 450 -> 2
                    view.shift == 1 -> 0
                    else -> 1
                }
                lastShift = now
            }
            Kind.LAYER -> view.layer = k.target
            Kind.CHAR -> typeChar(ic, k, nx, ny, x, y)
        }
        refresh()
    }

    /**
     * پیدا کردن ضربه‌ی مربوط به حرفی که پاک شد.
     * انتهای متن: فقط اگر آخرین ضربه همان حرف باشد.
     * وسط متن: فقط اگر در ۱۲۰ ضربه‌ی اخیر دقیقاً یک بار آمده باشد (تا اشتباه یاد نگیرد).
     */
    private fun takeStroke(c: String, mid: Boolean): Stroke {
        val lc = c.lowercase()
        if (!mid) {
            if (recent.isNotEmpty() && recent[recent.lastIndex].label == lc)
                return recent.removeAt(recent.lastIndex)
        } else {
            val from = max(0, recent.size - 120)
            val hits = (from until recent.size).filter { recent[it].label == lc }
            if (hits.size == 1) return recent.removeAt(hits[0])
        }
        return Stroke(lc, 0f, 0f, false)
    }

    private fun typeChar(ic: InputConnection, k: KeyDef, nx: Float, ny: Float, x: Float, y: Float) {
        val o = if (view.layer == 1 && view.shift > 0) k.out.uppercase() else k.out
        if (!(o[0].isLetter() || o == "\u200c")) endWord(ic)
        ic.commitText(o, 1)
        if (view.shift == 1) view.shift = 0
        if (!k.learn) return

        val now = SystemClock.uptimeMillis()
        store.strokeCommitted(k.label)
        val s = Stroke(k.label, x, y, true)

        // اصلاح انتهای متن: ۶ ثانیه؛ اصلاح وسط متن: ۳۰ ثانیه
        val window = if (midEdit) 30000L else 6000L
        if (deleted.isNotEmpty() && now - lastAct < window) {
            retyped.add(s)
            lastAct = now
            if (retyped.size >= deleted.size) { evaluate(); deleted.clear(); retyped.clear() }
        } else { deleted.clear(); retyped.clear() }

        recent.add(s)
        if (recent.size > 300) recent.removeAt(0)
        if (store.adaptive) store.learnSample(k.label, nx, ny, 0.01f)
    }

    /** «حذف و بازنویسی» را مقایسه می‌کند و از اشتباه‌ها یاد می‌گیرد */
    private fun evaluate() {
        val n = deleted.size
        if (n > 4) return
        val pairs = ArrayList<Pair<Stroke, Stroke>>()
        for (i in 0 until n) if (deleted[i].label != retyped[i].label) pairs.add(deleted[i] to retyped[i])
        if (pairs.isEmpty() || pairs.size > (n + 1) / 2) return
        for ((old, new) in pairs) {
            val want = view.cellOf(new.label) ?: continue
            val hit = view.cellOf(old.label) ?: continue
            // فقط اگر همسایه‌ی فیزیکی باشند، اشتباه لمسی حساب می‌شود
            if (abs(want.cx - hit.cx) / want.w > 1.7f || abs(want.cy - hit.cy) / want.h > 1.2f) continue
            if (old.known) {
                val nx = (old.x - want.cx) / want.w
                val ny = (old.y - want.cy) / want.h
                if (abs(nx) <= 1.3f && abs(ny) <= 1.1f && store.adaptive) store.learnSample(new.label, nx, ny, 0.12f)
            }
            store.recordError(new.label, old.label)
        }
        view.rebuild()
    }

    // ---------- کلمه و پیشنهاد ----------
    private fun trailingWord(ic: InputConnection): String {
        val t = ic.getTextBeforeCursor(24, 0)?.toString() ?: ""
        var i = t.length
        while (i > 0 && (t[i - 1].isLetter() || t[i - 1] == '\u200c')) i--
        return t.substring(i)
    }

    private fun endWord(ic: InputConnection) {
        if (!privateField) store.learnWord(trailingWord(ic))
    }

    private fun pickSuggestion(w: String) {
        val ic = currentInputConnection ?: return
        val cur = trailingWord(ic)
        ic.deleteSurroundingText(cur.length, 0)
        ic.commitText("$w ", 1)
        if (!privateField) store.learnWord(w)
        recent.clear(); deleted.clear(); retyped.clear()
        refresh()
    }

    private fun refresh() {
        val ic = currentInputConnection
        val cur = if (ic != null && !privateField) trailingWord(ic) else ""
        view.currentWord = cur
        view.suggestions = if (store.suggest && cur.isNotEmpty()) store.suggestions(cur) else emptyList()
        view.invalidate()
    }
}
