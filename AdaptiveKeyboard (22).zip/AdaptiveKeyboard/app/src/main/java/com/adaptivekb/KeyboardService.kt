package com.adaptivekb

import android.content.Context
import android.content.Intent
import android.inputmethodservice.InputMethodService
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.text.InputType
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.style.SuggestionSpan
import java.util.Locale
import android.view.View
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputConnection
import android.view.inputmethod.InputMethodManager
import kotlin.math.abs
import kotlin.math.max

class KeyboardService : InputMethodService() {

    private val store by lazy { Store.get(this) }
    private lateinit var view: KeyboardView

    /** known=false یعنی مختصات لمس این حرف را نداریم (فقط خود اشتباه ثبت می‌شود) */
    private class Stroke(val label: String, val x: Float, val y: Float, val known: Boolean)
    private class Fix(val orig: String, val fixed: String, val t: Long)
    /** target: کلمه‌ای که الان در متن است؛ options: گزینه‌هایی که کاربر می‌تواند به‌جای آن بگذارد */
    private class Mark(val word: String, val suggs: List<String>, val at: Int) { var seen = false }
    private class Repl(val target: String, val options: List<String>, val revert: Boolean)

    private val recent = ArrayList<Stroke>()    // آخرین ضربه‌های تایپ‌شده
    private val deleted = ArrayList<Stroke>()   // پاک‌شده‌ها (به ترتیب اصلی تایپ)
    private val retyped = ArrayList<Stroke>()   // بازنویسی بعد از پاک کردن
    private var lastAct = 0L
    private var lastShift = 0L
    private var midEdit = false                 // اصلاح وسط متن (نه انتهای آن)
    private var privateField = false            // رمز عبور یا حالت ناشناس: چیزی یاد نمی‌گیرد
    private var lastFix: Fix? = null
    private var repl: Repl? = null
    private val noFix = HashSet<String>()
    private val marks = ArrayList<Mark>()       // کلمه‌های علامت‌خورده؛ ببینیم کاربر یکی از پیشنهادها را انتخاب کرد یا نه
    private val handler = Handler(Looper.getMainLooper())
    private val showLoupeRunnable = Runnable {
        val ic = currentInputConnection ?: return@Runnable
        if (!::view.isInitialized || !store.loupe || privateField) return@Runnable
        val before = trailingWord(ic)
        val after = leadingWord(ic)
        val word = before + after
        if (word.length < 2) return@Runnable
        loupeW = word
        loupeJ = -1
        view.setLoupe(word, before.length)
        offerWords(ic, word)
    }
    private var lastEdit = 0L                   // آخرین ویرایش خودِ کیبورد (برای تشخیص لمس کاربر روی متن)
    private var loupeW: String? = null
    private var loupeJ = -1
    private var noSpell = false                 // فیلدهایی که غلط‌یاب در آن‌ها کار نمی‌کند
    private var wordCounter = 0
    private val markedAt = HashMap<String, Int>()   // هر کلمه در یک پنجره فقط یک بار علامت می‌خورد       // کلمه‌هایی که کاربر خودش نخواسته عوض شوند

    override fun onCreateInputView(): View {
        view = KeyboardView(this, store)
        view.onKey = { d, nx, ny, x, y -> handleKey(d, nx, ny, x, y) }
        view.onSuggestion = { pickSuggestion(it) }
        view.onLoupeLetter = { onLoupeLetter(it) }
        view.onLoupePick = { onLoupePick(it) }
        view.onLoupeClose = { hideLoupe() }
        view.onLoupeWord = { onLoupeWord(it) }
        view.onPicker = {
            (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker()
        }
        view.onSettings = {
            startActivity(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
        return view
    }

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        recent.clear(); deleted.clear(); retyped.clear()
        lastFix = null; repl = null; marks.clear()
        view.reload()
        view.shift = 0
        lastEdit = SystemClock.uptimeMillis()
        hideLoupe()
        val inType = info?.inputType ?: 0
        val variation = inType and InputType.TYPE_MASK_VARIATION
        privateField = when (inType and InputType.TYPE_MASK_CLASS) {
            InputType.TYPE_CLASS_TEXT ->
                variation == InputType.TYPE_TEXT_VARIATION_PASSWORD ||
                variation == InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD ||
                variation == InputType.TYPE_TEXT_VARIATION_WEB_PASSWORD
            InputType.TYPE_CLASS_NUMBER -> variation == InputType.TYPE_NUMBER_VARIATION_PASSWORD
            else -> false
        } || ((info?.imeOptions ?: 0) and EditorInfo.IME_FLAG_NO_PERSONALIZED_LEARNING) != 0
        noSpell = (inType and InputType.TYPE_MASK_CLASS) != InputType.TYPE_CLASS_TEXT ||
            variation == InputType.TYPE_TEXT_VARIATION_URI ||
            variation == InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS ||
            variation == InputType.TYPE_TEXT_VARIATION_WEB_EMAIL_ADDRESS ||
            (inType and InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS) != 0
        markedAt.clear()
        val cls = inType and InputType.TYPE_MASK_CLASS
        view.layer = if (cls == InputType.TYPE_CLASS_NUMBER || cls == InputType.TYPE_CLASS_PHONE) 8 else store.lastLayer
        refresh()
    }

    override fun onFinishInput() { super.onFinishInput(); store.save() }
    override fun onDestroy() { store.save(); super.onDestroy() }

    // ---------- کلیدها ----------
    private fun handleKey(k: KeyDef, nx: Float, ny: Float, x: Float, y: Float) {
        val ic = currentInputConnection ?: return
        lastEdit = SystemClock.uptimeMillis()
        // ذره‌بین باز و یک حرفش انتخاب شده: کلید بعدی همان حرف را عوض می‌کند، نه اینکه به کلمه اضافه شود
        val lw = loupeW
        if (lw != null && loupeJ in lw.indices) {
            if (k.kind == Kind.BACKSPACE) { onLoupePick("⌫"); return }
            if (k.kind == Kind.CHAR && k.out.isNotEmpty() && (k.out[0].isLetter() || k.out == "\u200c")) {
                val o = if (view.layer == 1 && view.shift > 0) k.out.uppercase() else k.out
                if (view.shift == 1) view.shift = 0
                onLoupePick(o, k.label)
                return
            }
        }
        handler.removeCallbacks(showLoupeRunnable)
        val keepLoupe = loupeW != null && (k.kind == Kind.CHAR || k.kind == Kind.BACKSPACE)
        if (loupeW != null && !keepLoupe) hideLoupe()
        if (k.kind == Kind.BACKSPACE && tryUndoFix(ic)) { repl = null; refresh(); return }
        if (k.kind != Kind.BACKSPACE) lastFix = null
        repl = null
        when (k.kind) {
            Kind.BACKSPACE -> {
                val sel = ic.getSelectedText(0)
                if (!sel.isNullOrEmpty()) {
                    ic.commitText("", 1); deleted.clear(); retyped.clear()
                } else {
                    val before = ic.getTextBeforeCursor(1, 0)?.toString() ?: ""
                    val mid = (ic.getTextAfterCursor(1, 0)?.length ?: 0) > 0
                    ic.deleteSurroundingText(1, 0)
                    if (retyped.isNotEmpty()) { deleted.clear(); retyped.clear() }
                    if (before.isNotEmpty()) {
                        deleted.add(0, takeStroke(before, mid))
                        midEdit = mid
                    }
                    lastAct = SystemClock.uptimeMillis()
                }
            }
            Kind.SPACE -> {
                autoFix(ic); ic.commitText(" ", 1)
                deleted.clear(); retyped.clear()
            }
            Kind.ENTER -> {
                autoFix(ic)
                val ei = currentInputEditorInfo
                val action = (ei?.imeOptions ?: 0) and EditorInfo.IME_MASK_ACTION
                val noAction = ((ei?.imeOptions ?: 0) and EditorInfo.IME_FLAG_NO_ENTER_ACTION) != 0
                if (ei == null || noAction || action == EditorInfo.IME_ACTION_NONE || action == EditorInfo.IME_ACTION_UNSPECIFIED)
                    ic.commitText("\n", 1)
                else ic.performEditorAction(action)
                deleted.clear(); retyped.clear()
            }
            Kind.SHIFT -> {
                val now = SystemClock.uptimeMillis()
                view.shift = when {
                    view.shift == 2 -> 0
                    view.shift == 1 && now - lastShift < 450 -> 2
                    view.shift == 1 -> 0
                    else -> 1
                }
                lastShift = now
            }
            Kind.LAYER -> {
                view.layer = k.target
                if (k.target == 0 || k.target == 1) store.lastLayer = k.target
            }
            Kind.CHAR -> typeChar(ic, k, nx, ny, x, y)
        }
        if (keepLoupe) syncLoupe()
        refresh()
    }

    /**
     * پیدا کردن ضربه‌ی مربوط به حرفی که پاک شد.
     * انتهای متن: فقط اگر آخرین ضربه همان حرف باشد.
     * وسط متن: فقط اگر در ۱۲۰ ضربه‌ی اخیر دقیقاً یک بار آمده باشد (تا اشتباه یاد نگیرد).
     */
    private fun takeStroke(c: String, mid: Boolean): Stroke {
        val lc = c.lowercase()
        if (!mid) {
            if (recent.isNotEmpty() && recent[recent.lastIndex].label == lc)
                return recent.removeAt(recent.lastIndex)
        } else {
            val from = max(0, recent.size - 120)
            val hits = (from until recent.size).filter { recent[it].label == lc }
            if (hits.size == 1) return recent.removeAt(hits[0])
        }
        return Stroke(lc, 0f, 0f, false)
    }

    private fun typeChar(ic: InputConnection, k: KeyDef, nx: Float, ny: Float, x: Float, y: Float) {
        val o = if (view.layer == 1 && view.shift > 0) k.out.uppercase() else k.out
        val mark = Character.getType(o[0]) == Character.NON_SPACING_MARK.toInt()
        if (!(o[0].isLetter() || o == "\u200c" || mark)) endWord(ic)
        ic.commitText(o, 1)
        if (view.shift == 1) view.shift = 0
        if (!k.learn) return

        val now = SystemClock.uptimeMillis()
        store.strokeCommitted(k.label)
        val s = Stroke(k.label, x, y, true)

        // اصلاح انتهای متن: ۶ ثانیه؛ اصلاح وسط متن: ۳۰ ثانیه
        val window = if (midEdit) 30000L else 6000L
        if (deleted.isNotEmpty() && now - lastAct < window) {
            retyped.add(s)
            lastAct = now
            if (retyped.size >= deleted.size) { evaluate(); deleted.clear(); retyped.clear() }
        } else { deleted.clear(); retyped.clear() }

        recent.add(s)
        if (recent.size > 300) recent.removeAt(0)
        if (store.adaptive) store.learnSample(k.label, nx, ny, 0.01f)
    }

    /** «حذف و بازنویسی» را مقایسه می‌کند و از اشتباه‌ها یاد می‌گیرد */
    private fun evaluate() {
        val n = deleted.size
        if (n > 4) return
        val pairs = ArrayList<Pair<Stroke, Stroke>>()
        for (i in 0 until n) if (deleted[i].label != retyped[i].label) pairs.add(deleted[i] to retyped[i])
        if (pairs.isEmpty() || pairs.size > (n + 1) / 2) return
        for ((old, new) in pairs) learnMistake(old, new.label, 0.12f)
        view.rebuild()
    }

    // ---------- کلمه، بافت جمله و تصحیح ----------
    private fun isWordChar(ch: Char) =
        ch.isLetter() || ch == '\u200c' || Character.getType(ch) == Character.NON_SPACING_MARK.toInt()

    private fun endsWithWord(ic: InputConnection): Boolean {
        val c = ic.getTextBeforeCursor(1, 0)?.toString()
        return !c.isNullOrEmpty() && isWordChar(c[0])
    }

    private fun trailingWord(ic: InputConnection): String {
        val t = ic.getTextBeforeCursor(24, 0)?.toString() ?: ""
        var i = t.length
        while (i > 0 && isWordChar(t[i - 1])) i--
        return t.substring(i)
    }

    /** آخرین n کلمه‌ی قبل از مکان‌نما */
    private fun wordsBefore(ic: InputConnection, n: Int): MutableList<String> {
        val t = ic.getTextBeforeCursor(120, 0)?.toString() ?: return ArrayList()
        val out = ArrayList<String>()
        val sb = StringBuilder()
        for (ch in t) {
            if (isWordChar(ch)) sb.append(ch)
            else if (sb.isNotEmpty()) { out.add(sb.toString()); sb.setLength(0) }
        }
        if (sb.isNotEmpty()) out.add(sb.toString())
        return if (out.size > n) ArrayList(out.subList(out.size - n, out.size)) else out
    }

    private fun endWord(ic: InputConnection) {
        if (privateField || !endsWithWord(ic)) return
        val ws = wordsBefore(ic, 2)
        if (ws.isEmpty()) return
        store.learnWord(ws.last())
        store.learnBigram(ws.getOrNull(ws.size - 2), ws.last())
    }

    /** کلمه‌ی old را (نزدیک‌ترین نمونه به مکان‌نما) با new عوض می‌کند، حتی اگر چند کلمه عقب‌تر باشد */
    private fun replaceWordBack(ic: InputConnection, old: String, new: String): Boolean {
        val t = ic.getTextBeforeCursor(120, 0)?.toString() ?: return false
        var idx = t.lastIndexOf(old)
        while (idx >= 0) {
            val beforeOk = idx == 0 || !isWordChar(t[idx - 1])
            val e = idx + old.length
            val afterOk = e >= t.length || !isWordChar(t[e])
            if (beforeOk && afterOk) break
            idx = if (idx == 0) -1 else t.lastIndexOf(old, idx - 1)
        }
        if (idx < 0) return false
        val tail = t.substring(idx)
        ic.deleteSurroundingText(tail.length, 0)
        ic.commitText(new + tail.substring(old.length), 1)
        return true
    }

    /**
     * هنگام فاصله/اینتر: چهار کلمه‌ی آخر را با توجه به کلمه‌های دو طرفشان می‌سنجد.
     * اگر بافت قاطع باشد، خودکار درست می‌کند؛ اگر مبهم باشد، گزینه‌ها را در نوار پیشنهاد می‌گذارد.
     */
    private fun autoFix(ic: InputConnection) {
        if (privateField || !endsWithWord(ic)) return
        val ws = wordsBefore(ic, 5)
        if (ws.isEmpty()) return
        val lastOrig = ws.last()
        // هیچ کلمه‌ای بدون اجازه‌ی تو عوض نمی‌شود: فقط علامت می‌خورد و تو انتخاب می‌کنی
        if (store.autoCorrect && !noSpell) {
            wordCounter++
            checkAccepted(wordsBefore(ic, 8))
            val lowest = max(0, ws.size - 4)
            for (i in ws.size - 1 downTo lowest) {
                val w = ws[i]
                val prevMark = markedAt[w]
                if (prevMark != null && wordCounter - prevMark < 5) continue
                val window = ws.filterIndexed { j, _ -> j != i }
                val d = WordBrain.decide(store, w, ws.getOrNull(i - 1), ws.getOrNull(i + 1), window)
                val single = d.single
                val sugg = if (single != null) listOf(single) else d.options.filter { it != w }
                if (sugg.isNotEmpty() && markWord(ic, w, sugg)) {
                    markedAt[w] = wordCounter
                    marks.add(Mark(w, sugg, wordCounter))
                    if (marks.size > 20) marks.removeAt(0)
                }
            }
        }
        implicitLearn(lastOrig)
        // کلمه‌ای که تایپ کردی همیشه یاد گرفته می‌شود؛ پس دفعه‌ی بعد مشکوک حساب نمی‌شود
        val last = ws.last()
        store.learnWord(last)
        store.learnBigram(ws.getOrNull(ws.size - 2), last)
    }

    /** کلمه‌ی غلط w و شکل درستش c فقط در یک حرف فرق دارند؛ آن حرف اشتباه لمسی حساب می‌شود */
    private fun learnWordTypo(w: String, c: String, rate: Float) {
        if (w.length != c.length) return
        var diff = -1
        for (i in w.indices) if (w[i] != c[i]) { if (diff >= 0) return; diff = i }
        if (diff < 0) return
        val tail = if (recent.size >= w.length) recent.subList(recent.size - w.length, recent.size) else null
        val aligned = tail != null && w.indices.all { tail[it].label == w[it].toString() }
        val old = if (aligned) tail!![diff] else Stroke(w[diff].toString(), 0f, 0f, false)
        learnMistake(old, c[diff].toString(), rate)
    }

    private fun implicitLearn(w: String) {
        if (!store.adaptive || w.length < 3 || store.words.containsKey(w)) return
        var best: String? = null
        var bn = 0
        for ((c, n) in store.words) {
            if (n < 3 || c.length != w.length || n <= bn) continue
            var cnt = 0
            for (i in w.indices) if (w[i] != c[i]) cnt++
            if (cnt == 1) { best = c; bn = n }
        }
        val b = best ?: return
        learnWordTypo(w, b, 0.05f)
    }

    /** یک اشتباه لمسی را ثبت می‌کند: انگشت به old.label خورده ولی منظور wantLabel بوده */
    private fun learnMistake(old: Stroke, wantLabel: String, rate: Float) {
        val want = view.cellOf(wantLabel) ?: return
        val hit = view.cellOf(old.label) ?: return
        if (abs(want.cx - hit.cx) / want.w > 1.7f || abs(want.cy - hit.cy) / want.h > 1.2f) return
        if (old.known) {
            val nx = (old.x - want.cx) / want.w
            val ny = (old.y - want.cy) / want.h
            if (abs(nx) <= 1.3f && abs(ny) <= 1.1f && store.adaptive) {
                // برای کلیدی که هنوز داده‌ی کمی دارد، سریع‌تر یاد می‌گیرد
                val r = if (store.stat(wantLabel).errors < 3) maxOf(rate, 0.25f) else rate
                store.learnSample(wantLabel, nx, ny, r)
            }
        }
        store.recordError(wantLabel, old.label)
    }

    // ---------- ذره‌بین ----------
    private fun leadingWord(ic: InputConnection): String {
        val t = ic.getTextAfterCursor(24, 0)?.toString() ?: ""
        var i = 0
        while (i < t.length && isWordChar(t[i])) i++
        return t.substring(0, i)
    }

    /** پیشنهاد کلمه برای ذره‌بین: از علامت‌های قبلی، یا همین‌جا از روی بافت جمله */
    private fun offerWords(ic: InputConnection, word: String) {
        if (!store.autoCorrect || noSpell || privateField) return
        var opts: List<String> = marks.firstOrNull { it.word == word }?.suggs ?: emptyList()
        if (opts.isEmpty()) {
            val ws = wordsBefore(ic, 5)
            val prevWords = if (trailingWord(ic).isNotEmpty()) ws.dropLast(1) else ws
            val d = WordBrain.decide(store, word, prevWords.lastOrNull(), null, prevWords.takeLast(3))
            val s = d.single
            opts = if (s != null) listOf(s) else d.options.filter { it != word }
        }
        if (opts.isNotEmpty()) view.setLoupeWords(opts.take(3))
    }

    /** کل کلمه‌ی زیر مکان‌نما با کلمه‌ی انتخاب‌شده عوض می‌شود */
    private fun onLoupeWord(w: String) {
        val ic = currentInputConnection ?: return
        val word = loupeW ?: return
        lastEdit = SystemClock.uptimeMillis()
        val before = trailingWord(ic)
        val after = leadingWord(ic)
        if (before + after != word) { hideLoupe(); return }
        ic.deleteSurroundingText(before.length, after.length)
        ic.commitText(w, 1)
        learnWordTypo(word, w, 0.08f)
        store.boost(w)
        marks.removeAll { it.word == word }
        syncLoupe()
        refresh()
    }

    /** کلمه‌ی زیر مکان‌نما را دوباره می‌خواند و ذره‌بین را به‌روز می‌کند */
    private fun syncLoupe() {
        if (loupeW == null) return
        val ic = currentInputConnection ?: return
        val before = trailingWord(ic)
        val after = leadingWord(ic)
        val word = before + after
        if (word.isEmpty()) { hideLoupe(); return }
        loupeW = word
        loupeJ = -1
        view.setLoupe(word, before.length)
        offerWords(ic, word)
    }

    private fun hideLoupe() {
        handler.removeCallbacks(showLoupeRunnable)
        loupeW = null; loupeJ = -1
        if (::view.isInitialized) view.setLoupe(null)
    }

    override fun onUpdateSelection(
        oldSelStart: Int, oldSelEnd: Int, newSelStart: Int, newSelEnd: Int,
        candidatesStart: Int, candidatesEnd: Int
    ) {
        super.onUpdateSelection(oldSelStart, oldSelEnd, newSelStart, newSelEnd, candidatesStart, candidatesEnd)
        if (!::view.isInitialized || !store.loupe || privateField) return
        // ویرایش‌های خودِ کیبورد را نادیده می‌گیریم؛ فقط لمس کاربر روی متن مهم است
        if (SystemClock.uptimeMillis() - lastEdit < 400) return
        if (newSelStart != newSelEnd) { handler.removeCallbacks(showLoupeRunnable); hideLoupe(); return }
        if (loupeW != null) { syncLoupe(); return }            // ذره‌بین باز است: همراه مکان‌نما می‌ماند
        // با تأخیر: اگر فوراً شروع به تایپ کنی (مثلاً حرفی وسط کلمه)، ذره‌بین اصلاً نمی‌آید
        handler.removeCallbacks(showLoupeRunnable)
        handler.postDelayed(showLoupeRunnable, 700)
    }

    /** حرف j از کلمه لمس شد: حرف‌های جایگزین (همسایه‌ها و حرف‌هایی که کلمه را معنادار می‌کنند) */
    private fun onLoupeLetter(j: Int) {
        val word = loupeW ?: return
        if (j !in word.indices) return
        if (j == loupeJ) { loupeJ = -1; view.setLoupeCandidates(-1, emptyList()); return }
        loupeJ = j
        val letter = word[j].toString()
        fun make(c: String) = word.substring(0, j) + c + word.substring(j + 1)
        val confused = store.confusion.entries
            .filter { it.key.endsWith(">$letter") }
            .sortedByDescending { it.value }
            .map { it.key.substringBefore(">") }
        val nb = Layouts.neighbors(letter)
        val list = ArrayList<String>()
        list.addAll((confused + nb + Layouts.letters()).distinct()
            .filter { it != letter && (store.words[make(it)] ?: 0) > 0 })
        list.addAll(confused.filter { it !in list }.take(3))
        list.addAll(nb.filter { it !in list }.take(6))
        val shown = ArrayList(list.take(8))
        shown.add("⌫")
        view.setLoupeCandidates(j, shown)
    }

    private fun onLoupePick(cand: String, learnLabel: String = cand) {
        val ic = currentInputConnection ?: return
        val word = loupeW ?: return
        val j = loupeJ
        if (j !in word.indices) return
        lastEdit = SystemClock.uptimeMillis()
        val before = trailingWord(ic)
        val after = leadingWord(ic)
        if (before + after != word) { hideLoupe(); return }
        val old = word[j].toString()
        val newWord = word.substring(0, j) + (if (cand == "⌫") "" else cand) + word.substring(j + 1)
        ic.deleteSurroundingText(before.length, after.length)
        ic.commitText(newWord, 1)
        if (cand != "⌫") learnMistake(takeStroke(old, true), learnLabel, 0.12f)
        if (!privateField) store.learnWord(newWord)
        syncLoupe()
        refresh()
    }

    /**
     * اگر کلمه‌ی علامت‌خورده دیگر توی متن نیست و یکی از پیشنهادهایش جایش آمده،
     * یعنی کاربر از منوی خود سیستم پیشنهاد را انتخاب کرده: کلمه‌ی درست به دایره‌ی لغات اضافه
     * و اشتباه لمسی ثبت می‌شود (مختصات انگشت را نداریم، پس فقط خودِ اشتباه).
     */
    private fun checkAccepted(ws: List<String>) {
        val iter = marks.iterator()
        while (iter.hasNext()) {
            val m = iter.next()
            if (m.word in ws) m.seen = true
            if (wordCounter - m.at > 6) {
                // کلمه علامت خورد ولی تو نگهش داشتی: بعد از دو بار دیگر هرگز علامتش نمی‌زنیم
                if (m.seen) store.noteIgnored(m.word)
                iter.remove(); continue
            }
            if (m.word in ws) continue
            val hit = m.suggs.firstOrNull { it in ws } ?: continue
            learnWordTypo(m.word, hit, 0.08f)
            store.boost(hit)
            iter.remove()
        }
    }

    private fun locateWord(t: String, old: String): Int {
        var idx = t.lastIndexOf(old)
        while (idx >= 0) {
            val beforeOk = idx == 0 || !isWordChar(t[idx - 1])
            val e = idx + old.length
            val afterOk = e >= t.length || !isWordChar(t[e])
            if (beforeOk && afterOk) return idx
            idx = if (idx == 0) -1 else t.lastIndexOf(old, idx - 1)
        }
        return -1
    }

    /**
     * زیر کلمه‌ی مشکوک خط قرمز می‌کشد (SuggestionSpan)؛
     * با لمس کلمه، خود سیستم فهرست پیشنهادها را نشان می‌دهد.
     */
    private fun markWord(ic: InputConnection, w: String, sugg: List<String>): Boolean {
        val t = ic.getTextBeforeCursor(120, InputConnection.GET_TEXT_WITH_STYLES) ?: return false
        val idx = locateWord(t.toString(), w)
        if (idx < 0) return false
        val sb = SpannableStringBuilder(t.subSequence(idx, t.length))
        for (sp in sb.getSpans(0, w.length, SuggestionSpan::class.java)) sb.removeSpan(sp)
        sb.setSpan(
            SuggestionSpan(this, Locale("fa"), sugg.toTypedArray(), SuggestionSpan.FLAG_MISSPELLED, null),
            0, w.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
        )
        ic.deleteSurroundingText(sb.length, 0)
        ic.commitText(sb, 1)
        return true
    }

    /** پاک‌کردنِ بلافاصله بعد از تصحیح خودکار، کلمه‌ی اصلی را برمی‌گرداند */
    private fun tryUndoFix(ic: InputConnection): Boolean {
        val lf = lastFix ?: return false
        lastFix = null
        if (SystemClock.uptimeMillis() - lf.t > 5000) return false
        val before = ic.getTextBeforeCursor(lf.fixed.length + 1, 0)?.toString() ?: return false
        if (before != lf.fixed + " ") return false
        ic.deleteSurroundingText(lf.fixed.length + 1, 0)
        ic.commitText(lf.orig, 1)
        store.boost(lf.orig)
        noFix.add(lf.orig)
        deleted.clear(); retyped.clear()
        return true
    }

    private fun pickSuggestion(w: String) {
        val ic = currentInputConnection ?: return
        val r = repl
        if (r != null && !endsWithWord(ic)) {
            if (replaceWordBack(ic, r.target, w)) {
                if (r.revert) { store.boost(w); noFix.add(w) }
                else if (w == r.target) noFix.add(w)
                else store.learnWord(w)
            }
            repl = null; lastFix = null
            recent.clear(); deleted.clear(); retyped.clear()
            refresh()
            return
        }
        val cur = trailingWord(ic)
        ic.deleteSurroundingText(cur.length, 0)
        ic.commitText("$w ", 1)
        if (!privateField) store.learnWord(w)
        recent.clear(); deleted.clear(); retyped.clear()
        refresh()
    }

    private fun refresh() {
        val ic = currentInputConnection
        val cur = if (ic != null && !privateField) trailingWord(ic) else ""
        view.currentWord = cur
        val r = repl
        view.suggestions = when {
            r != null && cur.isEmpty() -> r.options
            store.suggest && cur.isNotEmpty() -> store.suggestions(cur)
            else -> emptyList()
        }
        view.invalidate()
    }
}
